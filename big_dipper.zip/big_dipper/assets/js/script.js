var app = angular.module("myApp", []); 
// app.controller('myCtrl', function($scope) {
//   $scope.firstName = "John";
//   $scope.lastName = "Doe";
// });
app.controller('myCtrl', function($scope, $http) {


// $scope.loginsubmit = function() {
//           $http.post("controllers/authenticate.php")
// 		  .then(function(response) {
// 		      // $scope.results = response.data;
// 		  });
//       };






});