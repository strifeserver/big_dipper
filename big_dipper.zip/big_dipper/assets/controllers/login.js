$('#loginbtn').click( () => {
	const username = $('#username').val();
	const password = $('#password').val();

	let errorFlag = false;

$.ajax({
		url : 'controllers/authenticate_check.php',
		method : 'post',
		data : {username : username,
				password: password},
		async : false
	}).done ( data => {
		

			errorFlag = true; // set to true 
			if(data == "A"){
			swal({
			title: "Error",
			text: "The Username and Password you provided is invalid",
			icon: "error",
			button: "OK",
			});

			}

			if(data <= "30" || data == ""){

			var timeLeft = data;
		    var elem = document.getElementById('some_div');
		    
		    var timerId = setInterval(countdown, 1000);
		    
		    function countdown() {
		      if (timeLeft <= 0) {
		        clearTimeout(timerId);
		        location.reload();
		        timleft = 0;
		        errorFlag = false;
		        // doSomething();
		      } else {
		      	errorFlag = true;
		        elem.innerHTML = 'Login Disabled! '+timeLeft + ' seconds remaining. Click <a title="here" href="http://localhost/forgotpassword.php">here</a> to reset your password';
		        timeLeft--;

		      }
		    }		

		    swal({
				title: "Error",
				text: "Unable to login "+data,
				icon: "error",
				button: "OK",
			});
			}

			if(data == "valid"){
				errorFlag = false;


			} else if(data == "online"){
				errorFlag = true;
				swal({
				title: "Account is Logged In",
				text: "Account currently logged in. Contact administrator for further assistance ",
				icon: "error",
				button: "OK",
			});

			}

			console.log(errorFlag);
			console.log(timeLeft);



			console.log(data);

	
	});

	

	if(username.length == 0 ) {
		$('#usernamelabel').css('color' , 'red');
		errorFlag = true;
		swal({
		title: "Error",
		text: "Username field is required",
		icon: "error",
		button: "OK",
		});
	} 

	if(password.length == 0 ) {
		$('#passwordlabel').css('color' , 'red');
		errorFlag = true;
		swal({
		title: "Error",
		text: "Password field is required",
		icon: "error",
		button: "OK",
		});
	} 

if(errorFlag == false){
	$('#login_form').submit();
}

});
