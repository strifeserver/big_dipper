$('#confirmforgot').click( () => {
	const usernamea = $('#usernamea').val();
	const securityanswer = $('#securityanswer').val();
	let errorFlag = false;

$.ajax({
		url : 'controllers/authenticateanswer.php',
		method : 'post',
		data : {usernamea : usernamea,
				securityanswer : securityanswer},
		async : false
	}).done ( data => {
			
			errorFlag = true; // set to true 
			if(data == "A"){
			swal({
			title: "Error",
			text: "The Security Answer you provided is invalid",
			icon: "error",
			button: "OK",
			});

			}

			if(data <= "30" || data == ""){

			var timeLeft = data;
		    var elem = document.getElementById('some_div');
		    
		    var timerId = setInterval(countdown, 1000);
		    
		    function countdown() {
		      if (timeLeft <= 0) {
		        clearTimeout(timerId);
		        location.reload();
		        timleft = 0;
		        errorFlag = false;
		        // doSomething();
		      } else {
		      	errorFlag = true;
		        elem.innerHTML = 'Disabled! '+timeLeft + ' seconds remaining';
		        timeLeft--;

		      }
		    }		

		    swal({
				title: "Error",
				text: "Unable to Change Password "+data,
				icon: "error",
				button: "OK",
			});
			}

			if(data == "valid"){
				errorFlag = false;


			}

			console.log(errorFlag);
			console.log(timeLeft);



			console.log(data);

	
	});

	if(usernamea.length == 0 ) {
		$('#usernamelabel').css('color' , 'red');
		errorFlag = true;
		swal({
		title: "Error",
		text: "usernamea field is required",
		icon: "error",
		button: "OK",
		});
	} 



if(errorFlag == false){
	// $('#forgotconfirmform').submit();
	console.log(errorFlag);
	swal({
				title: "Success",
				text: "Password Successfully changed",
				icon: "success",
				button: "OK",
			}).then(() => {
			$('#forgotconfirmform').submit();
			});










}

});
