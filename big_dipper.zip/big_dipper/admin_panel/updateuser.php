<?php


require('template.php')
?>


<?php function gettitle(){
	echo 'Update Profile';
} ?>



<?php function getcontent(){ 
	require('../connection.php');

$id = $_GET['id'];
$sql = "SELECT * FROM users_info
 WHERE id = $id";

$result = mysqli_query($conn, $sql);
$result = mysqli_fetch_assoc($result);



$sql = "SELECT * FROM 
users as u
JOIN users_info as ui ON (u.id = ui.users_id)
JOIN statuses as s ON (s.id = u.status_id)
JOIN roles as r ON (r.id = u.role_id)

 WHERE u.id = $id";

$getinfo = mysqli_query($conn, $sql);
$getinfo = mysqli_fetch_assoc($getinfo);
// echo $getinfo;



	?>

<div class="container" style="margin-top: 50px;">
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Update Profile</h5>
    <hr>
	  <div class="row">
	    <div class="col-md-12">
	        	<form id="update_form"  action="controllers/updateuser_endpoint.php?id=<?php echo $result['id'];?>" method="POST">
	        		<h5><?php echo $getinfo['username']; ?>,  <?php echo $result['firstname']; ?> </h5>

			        <div class="col-md-5 offset-md-3 ">	
						<label for="username">Username: </label>
						<input type="text" class="form-control" value="<?php echo $getinfo['username']; ?>" disabled>
						<p></p>
						<br>
			        </div>

		 			<div class="col-md-6 offset-md-3">
						<h5>User Account Information</h5>

					</div>
					<hr>
					<div class="col-md-5 offset-md-3">	
						<label for="firstname"> First name </label>
						<input type="text" id="firstname" class="form-control" name="firstname" value="<?php echo $result['firstname']; ?>">
		        	</div>

		        	 <div class="col-md-5 offset-md-3">	
						<label for="lastname"> Last name </label>
						<input type="text" id="lastname" class="form-control" name="lastname" value="<?php echo $result['lastname']; ?>">
		        	</div>


		        	 <div class="col-md-5 offset-md-3">	
						<label for="address"> Address </label>
						<input type="text" id="address" class="form-control" name="address" value="<?php echo $result['address']; ?>">
		        	</div>

		        	 <div class="col-md-5 offset-md-3">	
						<label for="birthdate"> Birthdate</label>
						<input type="date" id="birthdate" class="form-control" name="birthdate" value="<?php echo $result['birthdate']; ?>">
		        	</div>


		        	 <div class="col-md-5 offset-md-3">	
						<label for="contactnumber"> Contact number </label>
						<input type="text" id="contactnumber" class="form-control" name="contactnumber" value="<?php echo $result['contact_number']; ?>">
		        	</div>


		        	<div class="col-md-5 offset-md-3">	
						<label for="role"> Barangay Branch</label>
						<!-- <input type="text" id="role" name="role" value=""> -->
						<select name="barangay_branch" class="form-control">
							<option value="<?php echo $getinfo['barangay_branch'] ?>" selected>Currently: <?php echo $getinfo['barangay_branch'];  ?></option> 
							<option value="Santolan">Santolan</option>
							<option value="Dela Paz">Dela Paz</option>
						</select>
		        	</div>


		        	<div class="col-md-5 offset-md-3">	
						<label for="role"> Role</label>
						<!-- <input type="text" id="role" name="role" value=""> -->
						<select name="role" class="form-control">
							<option value="<?php echo $getinfo['role_id'] ?>" selected>Currently: <?php echo $getinfo['role'];  ?></option> 
					<?php
							$sql = "SELECT * FROM roles";
		                $results = mysqli_query($conn, $sql);

		                foreach ($results as $result ){ 
		                  extract($result);
		                    ?>
		                    <option value="<?php echo $id; ?>"><?php echo $role; ?></option> 
		                      <?php }?> 
						</select>
		        	</div>

		        	<div class="col-md-5 offset-md-3">	
						<label for="status"> Status</label>
						<select name="status" class="form-control">
							<option value="<?php echo $getinfo['status_id']; ?>" selected>Currently: <?php echo $getinfo['status']; ?></option> 
							<?php
							$sql = "SELECT * FROM statuses";
		                $results = mysqli_query($conn, $sql);
		                foreach ($results as $result ){ 
		                  extract($result);
		                    ?>
		                    <option value="<?php echo $id; ?>"><?php echo $status; ?></option>
		                      <?php }?> 
						</select>
		        	</div>
		        	<div class="col-md-5 offset-md-4">
		        		<br>
					<button type="button" id="updatebtn" class="btn btn-primary" >Update Profile</button>
		        	</div>
				</form>
	      </div>
	    </div>
  </div>
</div>
</div>




























<script>
	// AJAX USERNAME 
$('#updatebtn').click( () => {
	const username = $('#username').val();
	const email = $('#email').val();
	const firstname = $('#firstname').val();
	const lastname = $('#lastname').val();
	const address = $('#address').val();
	const contactnumber = $('#contactnumber').val();
	let errorFlag = false;

	

	if(firstname.length == 0 ) {
		errorFlag = true;
		$('#firstname').next().css('color' , 'red');
		$('#firstname').next().html('this field is required');
	} 


	if(lastname.length == 0 ) {
		errorFlag = true;
		$('#lastname').next().css('color' , 'red');
		$('#lastname').next().html('this field is required');
	} 


	if(address.length == 0 ) {
		errorFlag = true;
		$('#address').next().css('color' , 'red');
		$('#address').next().html('this field is required');
	} 



	if(contactnumber.length == 0 ) {
		errorFlag = true;
		$('#contactnumber').next().css('color' , 'red');
		$('#contactnumber').next().html('this field is required');
	} 





if(errorFlag == false){
	$('#update_form').submit();
}

});


</script>

<?php } ?>