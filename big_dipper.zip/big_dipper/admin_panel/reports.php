<?php 


require_once('template.php');

function gettitle(){
	echo 'Reports';

}


function getcontent(){




?>


<div class="container">

<div class="row">
	
<div class="col l3 offset-l2">
	<h4>Reports</h4>
</div>
</div>




 <div class="row">

    <div class="col card s12 m7 l12 offset-l1">
 

        <div class="card-content col l4">
		<h5>Product list report</h5>

		<form target="_blank" method="post" action="controllers/productreport.php">  
            <input type="submit" name="productreport" class="btn btn-danger" value="Generate product list report" />  
        </form> 


        </div>

        <div class="card-content col l4">
		<h5>User list report</h5>
		

		<form target="_blank" method="post" action="controllers/userreport_endpoint.php">  
            <input type="submit" name="userreport" class="btn btn-danger" value="Generate user list report" />  
        </form> 

        </div>

        <div class="card-content col l4">
		<h5>Administrators list report</h5>

		<form target="_blank" method="post" action="controllers/adminlist_endpoint.php">  
            <input type="submit" name="userreport" class="btn btn-danger" value="Generate administrator list report" />
        </form>


        </div>


        <div class="card-content col l4">
		<h5>Events list report</h5>
		<form target="_blank" method="post" action="controllers/eventsreport_endpoint.php">  
            <input type="submit" name="userreport" class="btn btn-danger" value="Generate events list report" />
        </form>

        </div>

  


        <div class="card-content col l6">
		<h5>Levels of Access list report</h5>
	
		<form target="_blank" method="post" action="controllers/levelofaccess_endpoint.php">  
            <input type="submit" name="userreport" class="btn btn-danger" value="Generate levels of acess list report" />  
        </form> 

        </div>


   
		<div class="card-content col l4">
		<h5>Income graph report</h5>

        <form target="_blank" method="post" action="controllers/salesreport_endpoint.php">  
            <input type="submit" name="userreport" class="btn btn-danger" value="Generate income graph pdf report" />  
        </form> 
        </div>





    </div>
  </div>


<?php }  ?>



