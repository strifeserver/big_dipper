<?php


require('template.php')
?>


<?php function gettitle(){
	echo 'Help';
} ?>



<?php function getcontent(){ 
?>

<style>
.accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #ccc; 
}

.panel {
  padding: 0 18px;
  display: none;
  background-color: white;
  overflow: hidden;
}
</style>





<div class="container">
	<div class="row">
		<div class="col-md-12">
			


			<h2>H e l p</h2>

			<button class="accordion" style="margin-bottom: 10px;"><h4>Maintenance</h4></button>
			<div class="panel">
			 <button class="accordion"><h4> Account Management</h4></button>
				<div class="panel"><br><br>
				<h4>In Account Mangement you can create and update accounts for employees.</h4>
				<hr>
				<h5>To Create an Account Access </h5>
				<hr>

				 <img src="assets/images/acct1.png">
				 <h5>then fill up the fields to create an account</h5>
				 <img src="assets/images/acct2.png">
				</div>





				<button class="accordion"><h4>Roles Control</h4></button>
				<div class="panel">
					<h4>In Roles Control you can add and update accounts for employees and add report category under that role.</h4>
				<hr>
				 <h5>To Add new role click add role button</h5>
				 <img src="assets/images/role1.png">
				</div>

				<button class="accordion"><h4>SMS Module</h4></button>
				<div class="panel">
				<h4>In SMS Module you can view Inbox and Outbox and send text message</h4>
				<hr>
				 <h5>To Add new role click add role button</h5>
				 <img src="assets/images/sms1.png">
				</div>


				<button class="accordion"><h4>Database Management</h4></button>
				<div class="panel">
				 <h4>In Database Management you can view records database backup and backup database</h4>
				<hr>
				 <h5></h5>
				 <img src="assets/images/db1.png">
				</div>


			</div>

			<button class="accordion"><h4>Complaints Management</h4></button>
			<div class="panel">
			  <button class="accordion"><h4>Blotter</h4></button>
				<div class="panel">

				 <h4>In Blotter you can view the records / lists of complaints and create/record.</h4>
				<hr>
				 <h5></h5>
				 <img src="assets/images/complaint1.png">

				</div>
			  
				<button class="accordion"><h4>Processing</h4></button>
				<div class="panel">

				 <h4>In Processing this is where you update the complaint by The Severity, Department handled and staff in charge.</h4>
				<hr>
				 <h5></h5>
				 <img src="assets/images/processing.png">
				 
				</div>

			  <button class="accordion"><h4>Responding</h4></button>
				<div class="panel">

				 <h4>In Responding module, this is where you update the status of the case</h4>
				<hr>
				 <h5></h5>
				 <img src="assets/images/responding.png">
				 
				</div>
			  <button class="accordion"><h4>Assessment</h4></button>
				<div class="panel">

				 <h4>In Assessment, this where you update the remarks of the case</h4>
				<hr>
				 <h5></h5>
				 <img src="assets/images/remarks.png">
				 
				</div>
			</div>

			<button class="accordion"><h4>My Account</h4></button>
			<div class="panel">
			  <button class="accordion"><h4>My Account</h4></button>
				<div class="panel">

				 <h4>In My Account, this where you can view your account information and also change password</h4>
				<hr>
				 <h5></h5>
				 <img src="assets/images/myaccount.png">
				 
				</div>
			</div>





		</div>
	</div>
</div>
<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
</script>


<?php } ?>