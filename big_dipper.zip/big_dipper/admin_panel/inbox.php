<?php 


require_once('template.php');

function gettitle(){
  echo 'Inbox Management';
}


function getcontent(){



?>
<link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>

<div class="container">





 <div class="row">

    <div class="col s12 m7 l12 offset-l1 ">
      <h2>Inbox</h2>
      <div class="card">
        <div class="card-content">

          <?php 

            require('../connection.php');
            $sql = "SELECT * FROM incoming";
            $results = mysqli_query($conn, $sql);
           ?>
          <table id="table_id" class="display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Mobile Number</th>
                <th>Message Content</th>
                <th>Date Received</th>
            </tr>
            </thead>
          <tbody>

        <?php foreach ($results as $result ){ 
                        extract($result);
                         ?>
              <tr>
                  <td><?php echo $id; ?> </td>
                  <td><?php echo $mobile_1; ?> </td>
                  <td><?php echo $body; ?></td>
                  <td><?php echo $date_created; ?></td>
              </tr>
                <?php } ?> 

          </tbody>
      </table>
      </div>
    </div>
  </div>
</div>


<?php 






 ?>

 


 
<script type="text/javascript" src="assets/js/datatables.min.js"></script>

<script>





$(document).ready( function () {
    $('#table_id').DataTable();
} );

</script>
<?php } ?>

