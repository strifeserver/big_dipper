-- Database: `big_dipper` --
-- Table `audits` --
CREATE TABLE `audits` (
  `auditid` int(11) NOT NULL AUTO_INCREMENT,
  `activity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `account_id` int(11) NOT NULL,
  PRIMARY KEY (`auditid`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `audits_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `audits` (`auditid`, `activity`, `datetime`, `account_id`) VALUES
(1, 'superadmin logged out', '2019-06-02 18:59:29', 1),
(2, 'superadmin logged in', '2019-06-02 18:59:33', 1),
(3, 'superadmin Created a User Account under username of: newaccount', '2019-06-02 19:02:22', 1),
(4, 'MODULE | Accounts Management | USER: superadmin | ACTION: UPDATE |  TARGET: newaccount, (User) ', '2019-06-02 19:02:31', 1);

-- Table `database_audit` --
CREATE TABLE `database_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `database_name` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `file_path` varchar(255) NOT NULL,
  `generated_by` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table `roles` --
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `status` enum('active','in-active','','') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `role`, `status`) VALUES
(1, 'User', 'in-active'),
(2, 'Administrator', 'active');

-- Table `securityquestions` --
CREATE TABLE `securityquestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `securityquestions` (`id`, `name`) VALUES
(1, 'What was the name of your first pet?'),
(2, 'What was your childhood nickname?'),
(3, 'What is the model of your first car?');

-- Table `statuses` --
CREATE TABLE `statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `statuses` (`id`, `status`) VALUES
(1, 'Enabled'),
(2, 'Disabled');

-- Table `users` --
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT '1',
  `status_id` int(11) NOT NULL DEFAULT '1',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `login_check` timestamp NULL DEFAULT NULL,
  `logout_check` timestamp NULL DEFAULT NULL,
  `smsnotif` int(11) NOT NULL DEFAULT '1',
  `is_login` enum('0','1','','') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `users_fk0` (`role_id`),
  KEY `users_fk1` (`status_id`),
  CONSTRAINT `users_fk0` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `users_fk1` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role_id`, `status_id`, `date_created`, `login_check`, `logout_check`, `smsnotif`, `is_login`) VALUES
(1, 'superadmin', '889a3a791b3875cfae413574b53da4bb8a90d53e', '', 2, 1, '2018-09-04 18:53:39', '2019-03-21 17:31:37', '2019-03-21 17:25:58', 1, '1'),
(2, 'newaccount', '6383bfcee5d1150fbe5450d86a0c0f719d776d83', '', 1, 1, '2019-06-02 19:02:22', '', '', 1, '0');

-- Table `users_info` --
CREATE TABLE `users_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `securityquestion` int(11) NOT NULL,
  `securityanswer` varchar(255) NOT NULL,
  `users_id` int(11) NOT NULL,
  `barangay_branch` enum('Santolan','Dela Paz','','') NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `users_info_fk0` (`securityquestion`),
  KEY `users_info_fk1` (`users_id`),
  CONSTRAINT `users_info_fk0` FOREIGN KEY (`securityquestion`) REFERENCES `securityquestions` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `users_info_fk1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `users_info` (`id`, `firstname`, `lastname`, `address`, `birthdate`, `contact_number`, `securityquestion`, `securityanswer`, `users_id`, `barangay_branch`) VALUES
(1, 'Kerwin', 'Francisco', 'Address', '05-05-1995', '123456789', 3, 'superadmin', 1, 'Dela Paz'),
(2, 'newaccounta', 'newaccounta', 'newaccounta', '2000-01-01', '12345678999', 1, 'newaccount', 2, 'Dela Paz');

