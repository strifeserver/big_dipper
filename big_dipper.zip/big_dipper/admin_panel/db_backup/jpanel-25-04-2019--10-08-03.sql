-- Database: `jpanel` --
-- Table `audits` --
CREATE TABLE `audits` (
  `auditid` int(11) NOT NULL AUTO_INCREMENT,
  `activity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `account_id` int(11) NOT NULL,
  PRIMARY KEY (`auditid`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `audits_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `audits` (`auditid`, `activity`, `datetime`, `account_id`) VALUES
(1, 'MODULE | Database Management | USER: superadmin | ACTION: INSERT |  Database Name: db_backup21-03-2019', '2019-03-21 10:29:18', 1),
(2, 'superadmin logged out', '2019-03-21 11:17:07', 1),
(3, 'superadmin logged in', '2019-03-21 11:17:15', 1),
(4, 'superadmin logged out', '2019-03-21 11:18:06', 1),
(5, 'superadmin logged in', '2019-03-21 11:18:11', 1),
(6, 'superadmin logged out', '2019-03-21 11:23:00', 1),
(7, 'superadmin logged in', '2019-03-21 11:23:05', 1),
(8, 'superadmin logged out', '2019-03-21 11:23:35', 1),
(9, 'superadmin logged in', '2019-03-21 11:23:38', 1),
(10, 'superadmin logged out', '2019-03-21 11:24:08', 1),
(11, 'superadmin logged in', '2019-03-21 11:24:12', 1),
(12, 'superadmin logged out', '2019-03-21 11:24:25', 1),
(13, 'superadmin logged in', '2019-03-21 11:24:27', 1),
(14, 'superadmin logged out', '2019-03-21 11:25:25', 1),
(15, 'superadmin logged in', '2019-03-21 11:25:30', 1),
(16, 'superadmin logged out', '2019-03-21 11:25:49', 1),
(17, 'superadmin logged in', '2019-03-21 11:25:52', 1),
(18, 'superadmin logged out', '2019-03-21 11:39:01', 1),
(19, 'superadmin logged in', '2019-03-21 11:39:31', 1),
(20, 'superadmin logged out', '2019-03-21 11:39:35', 1),
(21, 'superadmin logged in', '2019-03-21 11:39:37', 1),
(22, 'superadmin logged out', '2019-03-21 11:54:03', 1),
(23, 'superadmin logged in', '2019-03-21 11:54:09', 1),
(24, 'superadmin logged out', '2019-03-21 11:54:18', 1),
(25, 'superadmin logged in', '2019-03-21 11:54:25', 1),
(26, 'superadmin logged out', '2019-03-21 11:56:05', 1),
(27, 'superadmin logged in', '2019-03-21 11:56:13', 1),
(28, 'superadmin logged out', '2019-03-21 11:56:49', 1),
(29, 'superadmin logged in', '2019-03-21 11:57:12', 1),
(30, 'superadmin logged out', '2019-03-21 11:58:05', 1),
(31, 'superadmin logged in', '2019-03-21 11:58:10', 1),
(32, 'superadmin logged out', '2019-03-21 11:58:23', 1),
(33, 'superadmin logged in', '2019-03-21 11:58:29', 1),
(34, 'superadmin logged out', '2019-03-21 11:58:47', 1),
(35, 'superadmin logged in', '2019-03-21 11:58:52', 1),
(36, 'superadmin logged out', '2019-03-21 11:59:06', 1),
(37, 'superadmin logged in', '2019-03-21 11:59:31', 1),
(38, 'superadmin logged out', '2019-03-21 11:59:34', 1),
(39, 'superadmin logged in', '2019-03-21 11:59:40', 1),
(40, 'superadmin logged out', '2019-03-21 11:59:56', 1),
(41, 'superadmin logged in', '2019-03-21 12:00:10', 1),
(42, 'superadmin logged out', '2019-03-21 12:46:47', 1),
(43, 'superadmin logged in', '2019-03-21 12:46:55', 1),
(44, 'superadmin logged out', '2019-03-21 12:47:14', 1),
(45, 'superadmin logged in', '2019-03-21 12:47:21', 1),
(46, 'superadmin logged out', '2019-03-21 13:05:32', 1),
(47, 'superadmin logged in', '2019-03-21 13:05:36', 1),
(48, 'superadmin logged out', '2019-03-21 13:06:05', 1),
(49, 'superadmin logged in', '2019-03-21 13:06:07', 1),
(50, 'superadmin logged out', '2019-03-21 13:06:53', 1),
(51, 'superadmin logged in', '2019-03-21 13:07:00', 1),
(52, 'superadmin logged out', '2019-03-21 13:10:16', 1),
(53, 'superadmin logged in', '2019-03-21 13:10:24', 1),
(54, 'superadmin logged out', '2019-03-21 13:10:43', 1),
(55, 'superadmin logged in', '2019-03-21 13:10:46', 1),
(56, 'superadmin logged out', '2019-03-21 13:11:37', 1),
(57, 'superadmin logged in', '2019-03-21 13:11:41', 1),
(58, 'superadmin logged out', '2019-03-21 13:11:54', 1),
(59, 'superadmin logged in', '2019-03-21 13:11:57', 1),
(60, 'superadmin logged out', '2019-03-21 13:13:00', 1),
(61, 'superadmin logged in', '2019-03-21 13:13:05', 1),
(62, 'superadmin logged out', '2019-03-21 15:02:30', 1),
(63, 'superadmin logged in', '2019-03-21 15:02:35', 1),
(64, 'superadmin logged out', '2019-03-21 15:05:36', 1),
(65, 'superadmin logged in', '2019-03-21 15:05:46', 1),
(66, 'superadmin logged out', '2019-03-21 15:51:01', 1),
(67, 'superadmin logged in', '2019-03-21 15:51:05', 1),
(68, 'superadmin logged out', '2019-03-21 15:52:18', 1),
(69, 'superadmin logged in', '2019-03-21 15:52:21', 1),
(70, 'superadmin logged out', '2019-03-21 15:53:14', 1),
(71, 'superadmin logged in', '2019-03-21 15:53:18', 1),
(72, 'superadmin logged out', '2019-03-21 16:00:26', 1),
(73, 'superadmin logged in', '2019-03-21 16:00:30', 1),
(74, 'superadmin logged out', '2019-03-21 16:04:10', 1),
(75, 'superadmin logged in', '2019-03-21 16:04:14', 1),
(76, 'superadmin logged out', '2019-03-21 16:05:07', 1),
(77, 'superadmin logged in', '2019-03-21 16:05:11', 1),
(78, 'superadmin logged out', '2019-03-21 16:05:25', 1),
(79, 'superadmin logged in', '2019-03-21 16:05:30', 1),
(80, 'superadmin logged out', '2019-03-21 16:06:15', 1),
(81, 'superadmin logged in', '2019-03-21 16:06:19', 1),
(82, 'superadmin logged out', '2019-03-21 16:07:46', 1),
(83, 'superadmin logged in', '2019-03-21 16:07:51', 1),
(84, 'superadmin logged out', '2019-03-21 16:08:10', 1),
(85, 'superadmin logged in', '2019-03-21 16:08:14', 1),
(86, 'superadmin logged out', '2019-03-21 16:08:45', 1),
(87, 'superadmin logged in', '2019-03-21 16:08:48', 1),
(88, 'superadmin logged out', '2019-03-21 16:12:35', 1),
(89, 'superadmin logged in', '2019-03-21 16:12:43', 1),
(90, 'superadmin logged out', '2019-03-21 16:14:52', 1),
(91, 'superadmin logged in', '2019-03-21 16:14:55', 1),
(92, 'superadmin logged out', '2019-03-21 16:49:36', 1),
(93, 'superadmin logged in', '2019-03-21 16:49:41', 1),
(94, 'superadmin logged out', '2019-03-21 16:50:53', 1),
(95, 'superadmin logged in', '2019-03-21 16:50:59', 1),
(96, 'superadmin logged out', '2019-03-21 16:52:01', 1),
(97, 'superadmin logged in', '2019-03-21 16:52:06', 1),
(98, 'superadmin logged out', '2019-03-21 17:04:56', 1),
(99, 'superadmin logged in', '2019-03-21 17:05:05', 1),
(100, 'superadmin logged out', '2019-03-21 17:07:40', 1),
(101, 'superadmin logged in', '2019-03-21 17:07:45', 1),
(102, 'superadmin logged out', '2019-03-21 17:07:58', 1),
(103, 'superadmin logged in', '2019-03-21 17:08:03', 1),
(104, 'superadmin logged out', '2019-03-21 17:08:13', 1),
(105, 'superadmin logged in', '2019-03-21 17:08:17', 1),
(106, 'superadmin logged out', '2019-03-21 17:08:23', 1),
(107, 'superadmin logged in', '2019-03-21 17:08:26', 1),
(108, 'superadmin logged out', '2019-03-21 17:09:42', 1),
(109, 'superadmin logged in', '2019-03-21 17:09:46', 1),
(110, 'superadmin logged out', '2019-03-21 17:10:30', 1),
(111, 'superadmin logged in', '2019-03-21 17:10:34', 1),
(112, 'superadmin logged out', '2019-03-21 17:10:57', 1),
(113, 'superadmin logged in', '2019-03-21 17:11:01', 1),
(114, 'superadmin logged out', '2019-03-21 17:11:40', 1),
(115, 'superadmin logged in', '2019-03-21 17:11:43', 1),
(116, 'superadmin logged out', '2019-03-21 17:13:21', 1),
(117, 'superadmin logged in', '2019-03-21 17:13:25', 1),
(118, 'superadmin logged out', '2019-03-21 17:13:46', 1),
(119, 'superadmin logged in', '2019-03-21 17:13:50', 1),
(120, 'superadmin logged out', '2019-03-21 17:14:07', 1),
(121, 'superadmin logged in', '2019-03-21 17:14:10', 1),
(122, 'superadmin logged out', '2019-03-21 17:14:19', 1),
(123, 'superadmin logged in', '2019-03-21 17:14:22', 1),
(124, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLMQ7PJRHUQ49', '2019-03-21 17:16:19', 1),
(125, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLMJVQ5IKGB6W', '2019-03-21 17:17:20', 1),
(126, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Update remarks test    ', '2019-03-21 17:24:56', 1),
(127, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Lupon Tagapamayapa Department    ', '2019-03-21 17:25:08', 1),
(128, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Desk Officer Department    ', '2019-03-21 17:25:15', 1),
(129, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-21 17:25:16', 1),
(130, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Administrator Department    ', '2019-03-21 17:25:21', 1),
(131, 'MODULE | Database Management | USER: superadmin | ACTION: INSERT |  Database Name: db_backup21-03-2019', '2019-03-21 17:25:27', 1),
(132, 'MODULE | Database Management | USER: superadmin | ACTION: INSERT |  Database Name: db_backup21-03-2019', '2019-03-21 17:25:40', 1),
(133, 'superadmin logged out', '2019-03-21 17:25:58', 1),
(134, 'superadmin logged in', '2019-03-21 17:31:37', 1),
(135, 'superadmin logged out', '2019-03-21 17:52:02', 1),
(136, 'superadmin logged in', '2019-03-21 17:52:06', 1),
(137, 'superadmin logged out', '2019-03-21 17:54:16', 1),
(138, 'superadmin logged in', '2019-03-21 17:54:21', 1),
(139, 'superadmin logged out', '2019-03-21 17:54:26', 1),
(140, 'superadmin logged in', '2019-03-21 22:29:49', 1),
(141, 'MODULE | Database Management | USER: superadmin | ACTION: INSERT |  Database Name: db_backup21-03-2019', '2019-03-21 22:29:56', 1),
(142, 'MODULE | Database Management | USER: superadmin | ACTION: INSERT |  Database Name: db_backup21-03-2019', '2019-03-21 22:30:01', 1),
(150, 'superadmin logged out', '2019-03-21 22:59:53', 1),
(151, 'superadmin logged in', '2019-03-21 23:00:01', 1),
(152, 'superadmin logged in', '2019-03-24 21:10:07', 1),
(153, 'superadmin logged in', '2019-03-26 08:41:51', 1),
(154, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 13:24:37', 1),
(155, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department 2    ', '2019-03-26 13:53:07', 1),
(156, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 13:54:23', 1),
(157, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE |  Complaint 4, Assign complaint_status 2    ', '2019-03-26 13:54:46', 1),
(158, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 14:05:33', 1),
(159, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 14:11:45', 1),
(160, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Administrator Department    ', '2019-03-26 14:28:31', 1),
(161, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Desk Officer Department    ', '2019-03-26 14:38:31', 1),
(162, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Lupon Tagapamayapa Department    ', '2019-03-26 14:38:45', 1),
(163, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Administrator Department    ', '2019-03-26 14:39:51', 1),
(164, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 14:43:38', 1),
(165, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Lupon Tagapamayapa Department    ', '2019-03-26 14:44:31', 1),
(166, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE |  Complaint 4, Assign complaint_status 2    ', '2019-03-26 14:48:03', 1),
(167, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE |  Complaint 4, Assign complaint_status 1    ', '2019-03-26 14:55:29', 1),
(168, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 14:55:56', 1),
(169, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 14:56:06', 1),
(170, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 14:59:34', 1),
(171, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 15:01:15', 1),
(172, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Desk Officer Department    ', '2019-03-26 15:01:33', 1),
(173, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department BCPC Department    ', '2019-03-26 15:02:17', 1),
(174, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE |  Complaint 4, Assign complaint_status 2    ', '2019-03-26 15:02:34', 1),
(175, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department     ', '2019-03-26 15:02:44', 1),
(176, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 8, Assign Department     ', '2019-03-26 15:02:53', 1),
(177, 'superadmin logged in', '2019-03-27 22:36:13', 1),
(178, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLMJ8DL1OWH9J', '2019-03-27 23:22:27', 1),
(179, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLMPBIF75EWDZ', '2019-03-27 23:22:58', 1),
(180, 'superadmin logged out', '2019-03-27 23:54:19', 1),
(182, 'superadmin logged in', '2019-03-30 14:19:40', 1),
(183, 'superadmin logged out', '2019-03-30 14:56:23', 1),
(184, 'superadmin logged in', '2019-03-30 15:01:37', 1),
(185, 'superadmin logged out', '2019-03-30 15:01:39', 1),
(186, 'superadmin logged in', '2019-03-30 15:01:45', 1),
(187, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department BCPC Department    ', '2019-03-30 15:45:53', 1),
(188, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 1, Assign Department BCPC Department    ', '2019-03-30 15:49:39', 1),
(189, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 4, Assign Department Lupon Tagapamayapa Department    ', '2019-03-30 15:51:55', 1),
(190, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 1, Assign Department Desk Officer Department    ', '2019-03-30 15:59:58', 1),
(191, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 1, Assign Department Desk Officer Department    ', '2019-03-30 16:01:10', 1),
(192, 'superadmin logged in', '2019-04-10 20:41:03', 1),
(193, 'superadmin logged out', '2019-04-10 21:56:17', 1),
(194, 'superadmin logged in', '2019-04-12 16:09:01', 1),
(195, 'superadmin logged out', '2019-04-12 16:12:59', 1),
(196, 'superadmin logged in', '2019-04-12 16:15:32', 1),
(197, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLMR3EKTYU5PT', '2019-04-12 16:20:46', 1),
(198, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 11, Assign Department Desk Officer Department    ', '2019-04-12 16:21:07', 1),
(199, 'superadmin logged out', '2019-04-12 17:29:37', 1),
(200, 'superadmin logged in', '2019-04-12 17:30:11', 1),
(201, 'superadmin logged out', '2019-04-12 17:30:41', 1),
(202, 'superadmin logged in', '2019-04-12 17:31:08', 1),
(203, 'superadmin logged out', '2019-04-12 17:31:27', 1),
(204, 'superadmin logged in', '2019-04-12 17:31:43', 1),
(205, 'superadmin logged out', '2019-04-12 17:31:50', 1),
(206, 'superadmin logged in', '2019-04-12 17:33:14', 1),
(207, 'vawc logged in', '2019-04-12 17:33:33', 5),
(208, 'vawc logged out', '2019-04-12 17:33:48', 5),
(209, 'superadmin logged out', '2019-04-12 17:34:04', 1),
(210, 'vawc logged in', '2019-04-12 17:34:11', 5),
(211, 'vawc logged out', '2019-04-12 17:34:46', 5),
(212, 'superadmin logged in', '2019-04-12 17:34:53', 1),
(213, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLMJJ5SDVQOVG', '2019-04-12 17:35:46', 1),
(214, 'vawc logged in', '2019-04-12 17:35:52', 5),
(215, 'MODULE | Complaints Management | USER: vawc | ACTION: UPDATE | Barangay Complaint 12, Assign Department Desk Officer Department    ', '2019-04-12 17:36:56', 5),
(216, 'superadmin logged out', '2019-04-12 17:38:10', 1),
(217, 'superadmin logged in', '2019-04-12 17:38:20', 1),
(218, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLMF9QVKSLQ8B', '2019-04-12 17:39:12', 1),
(219, 'vawc logged out', '2019-04-12 17:39:18', 5),
(220, 'deskofficer logged in', '2019-04-12 17:39:40', 2),
(221, 'MODULE | Complaints Management | USER: deskofficer | ACTION: UPDATE |  Complaint 13, Assign complaint_status 1    ', '2019-04-12 17:40:23', 2),
(222, 'MODULE | Complaints Management | USER: deskofficer | ACTION: UPDATE | Barangay Complaint 13, Assign Department Desk Officer Department    ', '2019-04-12 17:40:56', 2),
(223, 'deskofficer logged out', '2019-04-12 18:08:50', 2),
(224, 'vawc logged in', '2019-04-12 18:09:13', 5),
(225, 'vawc logged out', '2019-04-12 18:09:18', 5),
(226, 'superadmin logged out', '2019-04-12 18:23:49', 1),
(227, 'vawc logged in', '2019-04-12 18:25:35', 5),
(228, 'vawc logged out', '2019-04-12 18:25:40', 5),
(229, 'vawc logged in', '2019-04-12 18:26:39', 5),
(230, 'vawc logged out', '2019-04-12 18:27:15', 5),
(231, 'vawc logged in', '2019-04-12 18:27:31', 5),
(232, 'vawc logged out', '2019-04-12 18:27:34', 5),
(233, 'superadmin logged in', '2019-04-12 18:28:05', 1),
(234, 'vawc logged in', '2019-04-12 18:29:06', 5),
(235, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLM9KPJZNB4O1', '2019-04-12 18:29:25', 1),
(236, 'MODULE | Complaints Management | USER: superadmin | ACTION: UPDATE | Barangay Complaint 14, Assign Department Desk Officer Department    ', '2019-04-12 18:29:49', 1),
(237, 'vawc logged out', '2019-04-12 18:30:16', 5),
(238, 'bcpc logged in', '2019-04-12 18:31:30', 4),
(239, 'superadmin logged out', '2019-04-12 18:48:17', 1),
(240, 'MODULE | Complaints Management | USER: bcpc | ACTION: UPDATE | Barangay Complaint 14, Assign Department Desk Officer Department    ', '2019-04-12 18:48:34', 4),
(241, 'superadmin logged in', '2019-04-12 18:48:59', 1),
(242, 'bcpc logged out', '2019-04-12 18:49:11', 4),
(243, 'superadmin logged out', '2019-04-12 18:51:57', 1),
(245, 'superadmin logged in', '2019-04-12 18:52:39', 1),
(246, 'superadmin logged out', '2019-04-12 18:53:47', 1),
(247, 'superadmin logged in', '2019-04-12 18:58:06', 1),
(248, 'deskofficer logged in', '2019-04-12 18:59:01', 2),
(249, 'MODULE | Complaint Management | USER: superadmin | ACTION: INSERT |  Complaint Reference: CPLMXQPY9GNJIA', '2019-04-12 18:59:34', 1),
(250, 'MODULE | Complaints Management | USER: deskofficer | ACTION: UPDATE | Barangay Complaint 15, Assign Department Desk Officer Department    ', '2019-04-12 19:00:50', 2),
(251, 'superadmin logged in', '2019-04-18 09:09:25', 1),
(254, 'superadmin logged in', '2019-04-21 18:54:29', 1),
(255, 'superadmin logged in', '2019-04-24 10:12:33', 1),
(256, 'superadmin logged out', '2019-04-24 10:12:49', 1),
(257, 'vawc logged in', '2019-04-24 10:12:59', 5),
(258, 'vawc logged out', '2019-04-24 10:13:05', 5),
(259, 'vawc logged in', '2019-04-24 10:13:17', 5),
(260, 'vawc logged out', '2019-04-24 10:13:30', 5),
(261, 'superadmin logged in', '2019-04-24 10:13:34', 1),
(262, 'deskofficer logged in', '2019-04-24 10:17:35', 2),
(263, 'deskofficer logged out', '2019-04-24 10:18:01', 2),
(264, 'superadmin logged out', '2019-04-24 10:22:41', 1),
(265, 'superadmin logged in', '2019-04-24 10:22:51', 1),
(266, 'superadmin logged in', '2019-04-25 10:01:28', 1);

-- Table `barangay_complaints` --
CREATE TABLE `barangay_complaints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `complaint_reference` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `complaint_category` int(11) NOT NULL,
  `department` varchar(255) NOT NULL,
  `complainant` varchar(255) NOT NULL,
  `complainant_contact` varchar(255) NOT NULL,
  `being_complained` varchar(255) NOT NULL,
  `b_complained_contact` varchar(255) NOT NULL,
  `complaint_status` int(11) NOT NULL DEFAULT '1',
  `submitted_by` int(11) NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remarks` varchar(255) NOT NULL,
  `barangay_branch` varchar(255) NOT NULL,
  `severity` varchar(255) NOT NULL,
  `in_charge` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `submitted_by` (`submitted_by`),
  KEY `complaint_status` (`complaint_status`),
  KEY `complaint_category` (`complaint_category`),
  CONSTRAINT `barangay_complaints_ibfk_1` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `barangay_complaints_ibfk_2` FOREIGN KEY (`complaint_status`) REFERENCES `complaint_status` (`id`),
  CONSTRAINT `barangay_complaints_ibfk_3` FOREIGN KEY (`complaint_category`) REFERENCES `complaint_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `barangay_complaints` (`id`, `title`, `complaint_reference`, `description`, `complaint_category`, `department`, `complainant`, `complainant_contact`, `being_complained`, `b_complained_contact`, `complaint_status`, `submitted_by`, `date_updated`, `date_created`, `remarks`, `barangay_branch`, `severity`, `in_charge`) VALUES
(1, 'Title', 'CPLMJWVXMUYRLZ', '<p>Descriptiomn</p>', 1, 'Desk Officer Department', 'TEST NAMEEE', '09282876925', 'TESTNAME2', '09474875889', 1, 1, '2019-03-30 16:01:10', '2019-03-01 08:52:29', '', 'Antipolo', 'high', 'bcpc'),
(2, 'New Issue', 'CPLMZ7A228ZXO9', '<p>sdfsdfsddfsdfsdjfsdfsdfsdfsdf</p><p>sdsdf</p><p>sdf</p><p>sdf</p><p>sdf</p><p>sdf</p><p>sdf</p><p>sdf</p>', 2, 'VAWC Department', 'test1', '1234566789', 'test2', '13456789', 1, 1, '2019-03-26 13:24:18', '2019-03-03 04:31:15', '', 'Santolan', 'undefined', 'undefined'),
(3, 'issue3', 'CPLMHGAB1XODL9', '<p>sfgjkhjk</p><p>hjkhjk</p><p>hjkhjk</p>', 1, 'Administrator Department', 'fsdfsd', '1212121', 'sdfsdf', '121212', 1, 1, '2019-03-26 13:24:18', '2019-03-04 04:32:43', '', 'Santolan', 'undefined', 'undefined'),
(4, 'acclevel1', 'CPLMEVWLN5MFL6', '<p>acclevel1</p>', 1, 'Lupon Tagapamayapa Department', 'acclevel1', '12345679', 'acclevel1', '12345679', 2, 2, '2019-03-30 15:51:55', '2019-03-05 15:49:58', 'test', 'Santolan', 'undefined', 'bcpc'),
(5, 'test2<br>', 'CPLMJZDC24J3I6<br>', '<p>asdasdada</p><br>', 1, 'BCPC Department', 'asdasd<br>', '23423423423<br>', 'asdasd<br>', '2342342<br>', 1, 1, '2019-03-26 13:24:18', '2019-03-16 13:30:48', '', 'Santolan', 'undefined', 'undefined'),
(6, 'asdasd', 'CPLMFCMU7A42ND', '<p>asdsada</p>', 1, 'Administrator Department', 'asdasd', '311121', 'asdasd', '2121', 1, 1, '2019-03-26 13:24:18', '2019-03-16 13:32:02', '', 'Santolan', 'undefined', 'undefined'),
(7, 'rest', 'CPLMQ7PJRHUQ49', '<p>asdasdasd</p>', 4, 'VAWC Department', 'asdasdads', '1234567489', '123', '123456789', 1, 1, '2019-03-26 13:24:18', '2019-03-21 17:16:19', '', '', 'undefined', 'undefined'),
(8, 'asdsadsada', 'CPLMJVQ5IKGB6W', '<p><strong>asdsad</strong></p>', 4, 'VAWC Department', 'adsadsad', '1234567489', 'sadasd', '123456789', 1, 1, '2019-03-26 15:02:53', '2019-03-21 17:17:20', 'dfsfd', '', 'undefined', 'undefined'),
(9, 'NEWTITLE', 'CPLMJ8DL1OWH9J', '<p><strong>test</strong></p>', 1, 'BCPC Department', 'newname', '123456789', 'newname2', '12345679', 1, 1, '2019-03-27 23:22:27', '2019-03-27 23:22:27', '', 'santolan', '', ''),
(10, 'NEWTITLE2', 'CPLMPBIF75EWDZ', '<p><strong>test</strong></p>', 1, 'BCPC Department', 'newname', '123456789', 'newname2', '12345679', 1, 1, '2019-03-27 23:22:58', '2019-03-27 23:22:58', '', 'dela paz', '', ''),
(11, 'AMA ROBBERY', 'CPLMR3EKTYU5PT', '<p>afshd w d</p>', 1, 'Desk Officer Department', 'Kerr fracisco', '09474875889', 'Also Kerr', '09151940857', 1, 1, '2019-04-12 16:21:07', '2019-04-12 16:20:46', '', 'Santolan', 'high', 'lupontagapamayapa'),
(12, 'Child Abuse', 'CPLMJJ5SDVQOVG', '<p>qwertyuiopasdfghjkl</p>', 4, 'Desk Officer Department', 'Kerwin Francisco', '09474875889', 'Chris Posadas', '09151940857', 1, 1, '2019-04-12 17:36:56', '2019-04-12 17:35:46', '', 'Dela Paz', 'high', 'vawc'),
(13, 'Confiscated Knife', 'CPLMF9QVKSLQ8B', '<p>asdfghjklzxcvbnm</p>', 3, 'Desk Officer Department', 'kerr francisco', '09474875889', 'Chris Posadas', '09151940857', 1, 1, '2019-04-12 17:40:56', '2019-04-12 17:39:11', '', 'Dela Paz', 'normal', 'superadmin'),
(14, 'Killing spree', 'CPLM9KPJZNB4O1', '<p>asdadfghjkl;</p>', 1, 'Desk Officer Department', 'kerr francisco', '09474875889', 'Chris Posadas', '09151940857', 1, 1, '2019-04-12 18:48:34', '2019-04-12 18:29:25', '', 'Dela Paz', 'normal', 'lupontagapamayapa'),
(15, 'Missing Dog', 'CPLMXQPY9GNJIA', '<p>Labrador, colored brown. his name is popoy.&nbsp;</p>', 1, 'Desk Officer Department', 'Kerwin Francisco', '09474875889', 'Chris Posadas', '09151940857', 1, 1, '2019-04-12 19:00:50', '2019-04-12 18:59:34', '', 'Dela Paz', 'high', 'lupontagapamayapa');

-- Table `complaint_categories` --
CREATE TABLE `complaint_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complaint_category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `complaint_categories` (`id`, `complaint_category`) VALUES
(1, 'Blotter'),
(2, 'Misconduct of Behavior'),
(3, 'Barangay Council for the Protection of Children'),
(4, 'Violence Against Women');

-- Table `complaint_selects` --
CREATE TABLE `complaint_selects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_id` int(11) NOT NULL,
  `complaint_categories_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `complaint_categories_id` (`complaint_categories_id`),
  KEY `roles_id` (`roles_id`),
  CONSTRAINT `complaint_selects_ibfk_1` FOREIGN KEY (`complaint_categories_id`) REFERENCES `complaint_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `complaint_selects_ibfk_2` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `complaint_selects` (`id`, `roles_id`, `complaint_categories_id`) VALUES
(1, 2, 1),
(2, 2, 2),
(3, 2, 3),
(4, 2, 4),
(5, 3, 1),
(6, 3, 2),
(7, 3, 3),
(8, 3, 4),
(9, 5, 4),
(30, 7, 1),
(31, 4, 3);

-- Table `complaint_status` --
CREATE TABLE `complaint_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complaint_status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `complaint_status` (`id`, `complaint_status`) VALUES
(1, 'Pending'),
(2, 'Closed');

-- Table `database_audit` --
CREATE TABLE `database_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `database_name` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `file_path` varchar(255) NOT NULL,
  `generated_by` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `database_audit` (`id`, `database_name`, `date_created`, `file_path`, `generated_by`) VALUES
(1, 'db_backup21-03-2019', '2019-03-21 10:29:18', '../admin_panel/db_backup/jpanel-21-03-2019--10-29-18.sql', 'superadmin'),
(2, 'db_backup21-03-2019', '2019-03-21 17:25:27', '../admin_panel/db_backup/jpanel-21-03-2019--05-25-27.sql', 'superadmin'),
(3, 'db_backup21-03-2019', '2019-03-21 17:25:40', '../admin_panel/db_backup/jpanel-21-03-2019--05-25-40.sql', 'superadmin'),
(4, 'db_backup21-03-2019', '2019-03-21 22:29:56', '../admin_panel/db_backup/jpanel-21-03-2019--10-29-56.sql', 'superadmin'),
(5, 'db_backup21-03-2019', '2019-03-21 22:30:01', '../admin_panel/db_backup/jpanel-21-03-2019--10-30-01.sql', 'superadmin');

-- Table `incoming` --
CREATE TABLE `incoming` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile_1` varchar(15) NOT NULL,
  `body` text NOT NULL,
  `date_created` datetime NOT NULL,
  `date_received` varchar(15) NOT NULL,
  `time_received` varchar(15) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Table `messages` --
CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_num` varchar(255) NOT NULL,
  `msg_message` varchar(255) NOT NULL,
  `msg_status` varchar(255) NOT NULL DEFAULT 'sending',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `messages` (`msg_id`, `msg_num`, `msg_message`, `msg_status`) VALUES
(1, '+639282876925', 'asddad', 'sending');

-- Table `outgoing` --
CREATE TABLE `outgoing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile_1` varchar(15) NOT NULL,
  `body` text NOT NULL,
  `sms_status` int(11) NOT NULL,
  `date_sent` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `group_id` int(11) NOT NULL,
  `is_error` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1173 DEFAULT CHARSET=utf8;

-- Table `roles` --
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `status` enum('active','in-active','','') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `role`, `department`, `status`) VALUES
(1, 'User', 'User Department', 'in-active'),
(2, 'Administrator', 'Administrator Department', 'active'),
(3, 'Lupon Tagapamayapa', 'Lupon Tagapamayapa Department', 'active'),
(4, 'BCPC Officer', 'BCPC Department', 'active'),
(5, 'VAWC Officer', 'VAWC Department', 'active'),
(6, 'Role', 'Role Dept', 'in-active'),
(7, 'Desk Officer', 'Desk Officer Department', 'active'),
(8, 'none', '', 'in-active'),
(9, '', '', 'in-active'),
(10, '', '', 'in-active');

-- Table `securityquestions` --
CREATE TABLE `securityquestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `securityquestions` (`id`, `name`) VALUES
(1, 'What was the name of your first pet?'),
(2, 'What was your childhood nickname?'),
(3, 'What is the model of your first car?');

-- Table `statuses` --
CREATE TABLE `statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `statuses` (`id`, `status`) VALUES
(1, 'Enabled'),
(2, 'Disabled');

-- Table `users` --
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT '1',
  `status_id` int(11) NOT NULL DEFAULT '1',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `login_check` timestamp NULL DEFAULT NULL,
  `logout_check` timestamp NULL DEFAULT NULL,
  `smsnotif` int(11) NOT NULL DEFAULT '1',
  `is_login` enum('0','1','','') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `users_fk0` (`role_id`),
  KEY `users_fk1` (`status_id`),
  CONSTRAINT `users_fk0` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `users_fk1` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role_id`, `status_id`, `date_created`, `login_check`, `logout_check`, `smsnotif`, `is_login`) VALUES
(1, 'superadmin', '889a3a791b3875cfae413574b53da4bb8a90d53e', '', 2, 1, '2018-09-04 18:53:39', '2019-03-21 17:31:37', '2019-03-21 17:25:58', 1, '1'),
(2, 'deskofficer', 'dd785c67c6cedce1eeeb8333160095744aa10e7e', '', 7, 1, '2019-03-16 13:44:35', '2019-03-16 15:10:13', '2019-03-16 15:11:07', 1, '0'),
(3, 'lupontagapamayapa', '16faf9e4e3398247b5405e44d43b584931308b50', '', 3, 1, '2019-03-16 13:45:05', '', '', 1, '0'),
(4, 'bcpc', '6bb7f1a7fca86576c0b73a2cedc7d7d4f7b6c67d', '', 4, 1, '2019-03-16 13:45:49', '2019-03-16 15:11:12', '2019-03-16 15:14:43', 1, '0'),
(5, 'vawc', 'd65eec767267fd44f677bb7d8ffafa9b26db0983', '', 5, 1, '2019-03-16 13:46:17', '2019-03-16 14:43:09', '2019-03-16 14:48:37', 1, '0'),
(6, 'deskofficer2', '784146472f8bcbfe05564acfc8e068ddd01ec31f', '', 7, 1, '2019-03-16 13:51:19', '', '', 1, '0');

-- Table `users_info` --
CREATE TABLE `users_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `securityquestion` int(11) NOT NULL,
  `securityanswer` varchar(255) NOT NULL,
  `users_id` int(11) NOT NULL,
  `barangay_branch` enum('Santolan','Dela Paz','','') NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `users_info_fk0` (`securityquestion`),
  KEY `users_info_fk1` (`users_id`),
  CONSTRAINT `users_info_fk0` FOREIGN KEY (`securityquestion`) REFERENCES `securityquestions` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `users_info_fk1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `users_info` (`id`, `firstname`, `lastname`, `address`, `birthdate`, `contact_number`, `securityquestion`, `securityanswer`, `users_id`, `barangay_branch`) VALUES
(1, 'Kerwin', 'Francisco', 'Address', '05-05-1995', '123456789', 3, 'superadmin', 1, ''),
(2, 'deskofficer', 'deskofficer', 'deskofficer', '2000-01-01', '123456789', 1, 'deskofficer', 2, 'Dela Paz'),
(3, 'lupontagapamayapa', 'lupontagapamayapa', 'lupontagapamayapa', '2000-01-01', '123456789', 1, 'lupontagapamayapa', 3, 'Santolan'),
(4, 'bcpc', 'bcpc', 'bcpc', '2000-01-01', '123456789', 1, 'bcpc', 4, 'Santolan'),
(5, 'vawc', 'vawc', 'vawc', '2000-01-01', '123456789', 1, 'vawc', 5, 'Santolan'),
(6, 'deskofficer2', 'deskofficer2', 'deskofficer2', '2000-01-01', '123456789', 1, 'deskofficer2', 6, 'Santolan');

