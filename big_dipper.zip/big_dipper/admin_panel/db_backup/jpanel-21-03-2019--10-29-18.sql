-- Database: `jpanel` --
-- Table `audits` --
CREATE TABLE `audits` (
  `auditid` int(11) NOT NULL AUTO_INCREMENT,
  `activity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `account_id` int(11) NOT NULL,
  PRIMARY KEY (`auditid`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `audits_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `barangay_complaints` --
CREATE TABLE `barangay_complaints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `complaint_reference` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `complaint_category` int(11) NOT NULL,
  `department` varchar(255) NOT NULL,
  `complainant` varchar(255) NOT NULL,
  `complainant_contact` varchar(255) NOT NULL,
  `being_complained` varchar(255) NOT NULL,
  `b_complained_contact` varchar(255) NOT NULL,
  `complaint_status` int(11) NOT NULL DEFAULT '1',
  `submitted_by` int(11) NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remarks` varchar(255) NOT NULL,
  `barangay_branch` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `submitted_by` (`submitted_by`),
  KEY `complaint_status` (`complaint_status`),
  KEY `complaint_category` (`complaint_category`),
  CONSTRAINT `barangay_complaints_ibfk_1` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `barangay_complaints_ibfk_2` FOREIGN KEY (`complaint_status`) REFERENCES `complaint_status` (`id`),
  CONSTRAINT `barangay_complaints_ibfk_3` FOREIGN KEY (`complaint_category`) REFERENCES `complaint_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `barangay_complaints` (`id`, `title`, `complaint_reference`, `description`, `complaint_category`, `department`, `complainant`, `complainant_contact`, `being_complained`, `b_complained_contact`, `complaint_status`, `submitted_by`, `date_updated`, `date_created`, `remarks`, `barangay_branch`) VALUES
(1, 'Title', 'CPLMJWVXMUYRLZ', '<p>Description</p>', 1, 'BCPC Department', 'Complainant Name', '123456789', 'Defendant Name', '123546789', 1, 1, '2019-03-16 15:07:28', '2019-03-01 08:52:29', '', 'Santolan'),
(2, 'New Issue', 'CPLMZ7A228ZXO9', '<p>sdfsdfsddfsdfsdfsdfsdfsdfsdf</p><p>sdsdf</p><p>sdf</p><p>sdf</p><p>sdf</p><p>sdf</p><p>sdf</p><p>sdf</p>', 2, 'VAWC Department', 'test1', '1234566789', 'test2', '13456789', 1, 1, '2019-03-16 15:04:06', '2019-03-03 04:31:15', '', 'Santolan'),
(3, 'issue3', 'CPLMHGAB1XODL9', '<p>sfgjkhjk</p><p>hjkhjk</p><p>hjkhjk</p>', 1, 'Administrator Department', 'fsdfsd', '1212121', 'sdfsdf', '121212', 1, 1, '2019-03-16 13:37:51', '2019-03-04 04:32:43', '', 'Santolan'),
(4, 'acclevel1', 'CPLMEVWLN5MFL6', '<p>acclevel1</p>', 1, 'VAWC Department', 'acclevel1', '12345679', 'acclevel1', '12345679', 1, 2, '2019-03-16 13:37:48', '2019-03-05 15:49:58', 'UPDATE', 'Santolan'),
(5, 'test2<br>', 'CPLMJZDC24J3I6<br>', '<p>asdasdada</p><br>', 1, 'BCPC Department', 'asdasd<br>', '23423423423<br>', 'asdasd<br>', '2342342<br>', 1, 1, '2019-03-16 15:12:36', '2019-03-16 13:30:48', '', 'Santolan'),
(6, 'asdasd', 'CPLMFCMU7A42ND', '<p>asdsada</p>', 1, 'Administrator Department', 'asdasd', '311121', 'asdasd', '2121', 1, 1, '2019-03-16 13:32:02', '2019-03-16 13:32:02', '', 'Santolan');

-- Table `complaint_categories` --
CREATE TABLE `complaint_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complaint_category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `complaint_categories` (`id`, `complaint_category`) VALUES
(1, 'Blotter'),
(2, 'Misconduct of Behavior'),
(3, 'Barangay Council for the Protection of Children'),
(4, 'Violence Against Women');

-- Table `complaint_selects` --
CREATE TABLE `complaint_selects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_id` int(11) NOT NULL,
  `complaint_categories_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `complaint_categories_id` (`complaint_categories_id`),
  KEY `roles_id` (`roles_id`),
  CONSTRAINT `complaint_selects_ibfk_1` FOREIGN KEY (`complaint_categories_id`) REFERENCES `complaint_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `complaint_selects_ibfk_2` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `complaint_selects` (`id`, `roles_id`, `complaint_categories_id`) VALUES
(1, 2, 1),
(2, 2, 2),
(3, 2, 3),
(4, 2, 4),
(5, 3, 1),
(6, 3, 2),
(7, 3, 3),
(8, 3, 4),
(9, 5, 4),
(30, 7, 1),
(31, 4, 3);

-- Table `complaint_status` --
CREATE TABLE `complaint_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complaint_status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `complaint_status` (`id`, `complaint_status`) VALUES
(1, 'Pending'),
(2, 'Closed');

-- Table `database_audit` --
CREATE TABLE `database_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `database_name` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `file_path` varchar(255) NOT NULL,
  `generated_by` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table `messages` --
CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_num` varchar(255) NOT NULL,
  `msg_message` varchar(255) NOT NULL,
  `msg_status` varchar(255) NOT NULL DEFAULT 'sending',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=latin1;

INSERT INTO `messages` (`msg_id`, `msg_num`, `msg_message`, `msg_status`) VALUES
(1, '+639055006612', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55b961b5627d62', 'sent'),
(2, '+639055006612', 'Announcement!test sms', 'sent'),
(3, '+639282876925', 'Announcement!test sms', 'sent'),
(4, '+63639282876925', 'Announcement!test sms', 'sent'),
(5, '+639260325038', 'Announcement!test sms', 'sent'),
(6, '+6312345678', 'Announcement!test sms', 'sent'),
(7, '+6312345678', 'Announcement!test sms', 'sent'),
(8, '+6309055006612', 'Announcement!test sms', 'sent'),
(9, '+6309055006612', 'Announcement!test sms', 'sent'),
(10, '+639284676841', 'Announcement!test sms', 'sent'),
(11, '+63+639052910146', 'Announcement!test sms', 'sent'),
(12, '+639282876925', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55b961c1d81eba', 'sent'),
(13, '+639260325038', 'Announcement!sms test 3', 'sent'),
(14, '+639055006612', 'Announcement!sms test 3', 'sent'),
(15, '+639282876925', 'Announcement!sms test 3', 'sent'),
(16, '+639260325038', 'Announcement!sms test 3', 'sent'),
(17, '+6312345678', 'Announcement!sms test 3', 'sent'),
(18, '+6312345678', 'Announcement!sms test 3', 'sent'),
(19, '+639055006612', 'Announcement!sms test 3', 'sent'),
(20, '+639055006612', 'Announcement!sms test 3', 'sent'),
(21, '+639260325038', 'Announcement!sms test 3', 'sent'),
(22, '+639282876925', 'Announcement!sms test 3', 'sent'),
(23, '+639282876925', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55b964a7d082e1', 'sent'),
(24, '+639282876925', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b964cf5a9a28', 'sent'),
(25, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b9fa9eee4598', 'sent'),
(26, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b9fae79b7357', 'sent'),
(27, '+639260325038', 'Announcement!sms test 4', 'sent'),
(28, '+639055006612', 'Announcement!sms test 4', 'sent'),
(29, '+639282876925', 'Announcement!sms test 4', 'sent'),
(30, '+639260325038', 'Announcement!sms test 4', 'sent'),
(31, '+6312345678', 'Announcement!sms test 4', 'sent'),
(32, '+6312345678', 'Announcement!sms test 4', 'sent'),
(33, '+639055006612', 'Announcement!sms test 4', 'sent'),
(34, '+639055006612', 'Announcement!sms test 4', 'sent'),
(35, '+639284676841', 'Announcement!sms test 4', 'sent'),
(36, '+639052910146', 'Announcement!sms test 4', 'sent'),
(37, '+6309055006612', 'Announcement!sms test 4', 'sent'),
(38, '+639260325038', 'Announcement!sms test 4', 'sent'),
(39, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b9fb3c4221db', 'sent'),
(40, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b9fb49e812f3', 'sent'),
(41, '+639260325038', 'Announcement!test', 'sent'),
(42, '+639055006612', 'Announcement!test', 'sent'),
(43, '+639282876925', 'Announcement!test', 'sent'),
(44, '+639260325038', 'Announcement!test', 'sent'),
(45, '+6312345678', 'Announcement!test', 'sent'),
(46, '+6312345678', 'Announcement!test', 'sent'),
(47, '+639055006612', 'Announcement!test', 'sent'),
(48, '+639055006612', 'Announcement!test', 'sent'),
(49, '+639284676841', 'Announcement!test', 'sent'),
(50, '+639052910146', 'Announcement!test', 'sent'),
(51, '+6309055006612', 'Announcement!test', 'sent'),
(52, '+639260325038', 'Announcement!test', 'sent'),
(53, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b9fb6241aa77', 'sent'),
(54, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b9fb93f42732', 'sent'),
(55, '+639260325038', 'Announcement!tes', 'sent'),
(56, '+639055006612', 'Announcement!tes', 'sent'),
(57, '+639282876925', 'Announcement!tes', 'sent'),
(58, '+639260325038', 'Announcement!tes', 'sent'),
(59, '+6312345678', 'Announcement!tes', 'sent'),
(60, '+6312345678', 'Announcement!tes', 'sent'),
(61, '+639055006612', 'Announcement!tes', 'sent'),
(62, '+639055006612', 'Announcement!tes', 'sent'),
(63, '+639284676841', 'Announcement!tes', 'sent'),
(64, '+639052910146', 'Announcement!tes', 'sent'),
(65, '+6309055006612', 'Announcement!tes', 'sent'),
(66, '+639260325038', 'Announcement!tes', 'sent'),
(67, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b9fd48cf37e1', 'sent'),
(68, '+639284676841', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5b9fd57394a28', 'sent'),
(69, '+639055006612', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5ba07b521c74b', 'sent'),
(70, '+639260325038', 'Announcement!test lang sir', 'sent'),
(71, '+639055006612', 'Announcement!test lang sir', 'sent'),
(72, '+639282876925', 'Announcement!test lang sir', 'sent'),
(73, '+639260325038', 'Announcement!test lang sir', 'sent'),
(74, '+6312345678', 'Announcement!test lang sir', 'sent'),
(75, '+6312345678', 'Announcement!test lang sir', 'sent'),
(76, '+639055006612', 'Announcement!test lang sir', 'sent'),
(77, '+639055006612', 'Announcement!test lang sir', 'sent'),
(78, '+639284676841', 'Announcement!test lang sir', 'sent'),
(79, '+639052910146', 'Announcement!test lang sir', 'sent'),
(80, '+6309055006612', 'Announcement!test lang sir', 'sent'),
(81, '+639260325038', 'Announcement!test lang sir', 'sent'),
(82, '+63', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55ba10a534cf4a', 'sent'),
(83, '+63', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55ba113a6603a4', 'sent'),
(84, '+63', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55ba114bac6473', 'sent'),
(85, '+63', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55ba1167729fa4', 'sent'),
(86, '+63', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55ba11679e4ec0', 'sent'),
(87, '+63', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55ba119870d441', 'sent'),
(88, '+639260325038', 'Announcement!sms test defense', 'sent'),
(89, '+639055006612', 'Announcement!sms test defense', 'sent'),
(90, '+639282876925', 'Announcement!sms test defense', 'sent'),
(91, '+639260325038', 'Announcement!sms test defense', 'sent'),
(92, '+6312345678', 'Announcement!sms test defense', 'sent'),
(93, '+6312345678', 'Announcement!sms test defense', 'sent'),
(94, '+639055006612', 'Announcement!sms test defense', 'sent'),
(95, '+639055006612', 'Announcement!sms test defense', 'sent'),
(96, '+639284676841', 'Announcement!sms test defense', 'sent'),
(97, '+639052910146', 'Announcement!sms test defense', 'sent'),
(98, '+6309055006612', 'Announcement!sms test defense', 'sent'),
(99, '+639260325038', 'Announcement!sms test defense', 'sent'),
(100, '+6309055006612', 'Announcement!sms test defense', 'sent'),
(101, '+639260325038', 'Announcement!demo', 'sent'),
(102, '+639055006612', 'Announcement!demo', 'sent'),
(103, '+639282876925', 'Announcement!demo', 'sent'),
(104, '+639260325038', 'Announcement!demo', 'sent'),
(105, '+6312345678', 'Announcement!demo', 'sent'),
(106, '+6312345678', 'Announcement!demo', 'sent'),
(107, '+639055006612', 'Announcement!demo', 'sent'),
(108, '+639055006612', 'Announcement!demo', 'sent'),
(109, '+639284676841', 'Announcement!demo', 'sent'),
(110, '+639052910146', 'Announcement!demo', 'sent'),
(111, '+6309055006612', 'Announcement!demo', 'sent'),
(112, '+639260325038', 'Announcement!demo', 'sent'),
(113, '+6309055006612', 'Announcement!demo', 'sent'),
(114, '+639284676841', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5ba345aab302e', 'sent'),
(115, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5ba346c47bf95', 'sent'),
(116, '+639260325038', 'Announcement!test', 'sent'),
(117, '+639055006612', 'Announcement!test', 'sent'),
(118, '+639282876925', 'Announcement!test', 'sent'),
(119, '+639260325038', 'Announcement!test', 'sent'),
(120, '+6312345678', 'Announcement!test', 'sent'),
(121, '+6312345678', 'Announcement!test', 'sent'),
(122, '+639055006612', 'Announcement!test', 'sent'),
(123, '+639055006612', 'Announcement!test', 'sent'),
(124, '+639284676841', 'Announcement!test', 'sent'),
(125, '+639052910146', 'Announcement!test', 'sent'),
(126, '+6309055006612', 'Announcement!test', 'sent'),
(127, '+639260325038', 'Announcement!test', 'sent'),
(128, '+6309055006612', 'Announcement!test', 'sent'),
(129, '+639260325038', 'Announcement!diiscipleship training', 'sent'),
(130, '+639055006612', 'Announcement!diiscipleship training', 'sent'),
(131, '+639282876925', 'Announcement!diiscipleship training', 'sent'),
(132, '+639260325038', 'Announcement!diiscipleship training', 'sent'),
(133, '+6312345678', 'Announcement!diiscipleship training', 'sent'),
(134, '+6312345678', 'Announcement!diiscipleship training', 'sent'),
(135, '+639055006612', 'Announcement!diiscipleship training', 'sent'),
(136, '+639055006612', 'Announcement!diiscipleship training', 'sent'),
(137, '+639284676841', 'Announcement!diiscipleship training', 'sent'),
(138, '+639052910146', 'Announcement!diiscipleship training', 'sent'),
(139, '+6309055006612', 'Announcement!diiscipleship training', 'sent'),
(140, '+639260325038', 'Announcement!diiscipleship training', 'sent'),
(141, '+6309055006612', 'Announcement!diiscipleship training', 'sent'),
(142, '+639260325038', 'Announcement!discipleship training', 'sent'),
(143, '+639055006612', 'Announcement!discipleship training', 'sent'),
(144, '+639282876925', 'Announcement!discipleship training', 'sent'),
(145, '+639260325038', 'Announcement!discipleship training', 'sent'),
(146, '+6312345678', 'Announcement!discipleship training', 'sent'),
(147, '+6312345678', 'Announcement!discipleship training', 'sent'),
(148, '+639055006612', 'Announcement!discipleship training', 'sent'),
(149, '+639055006612', 'Announcement!discipleship training', 'sent'),
(150, '+639284676841', 'Announcement!discipleship training', 'sent'),
(151, '+639052910146', 'Announcement!discipleship training', 'sent'),
(152, '+6309055006612', 'Announcement!discipleship training', 'sent'),
(153, '+639260325038', 'Announcement!discipleship training', 'sent'),
(154, '+6309055006612', 'Announcement!discipleship training', 'sent'),
(155, '+639152056292', 'Announcement!discipleship training', 'sent'),
(156, '+639299585081', 'Announcement!discipleship training', 'sent'),
(157, '+639152056292', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5ba378ed7faa9', 'sent'),
(158, '+639260325038', 'VCCFI Online ShopYou have successfully placed an order at VCCFI Shop as the transaction code of5ba3c3f28ce7e', 'sent'),
(159, '+63', 'VCCFIYou have successfully placed an order at VCCFI Shop as the transaction code of55ba4eb88ea3cc', 'sending');

-- Table `roles` --
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `status` enum('active','in-active','','') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `role`, `department`, `status`) VALUES
(1, 'User', 'User Department', 'in-active'),
(2, 'Administrator', 'Administrator Department', 'active'),
(3, 'Lupon Tagapamayapa', 'Lupon Tagapamayapa Department', 'active'),
(4, 'BCPC Officer', 'BCPC Department', 'active'),
(5, 'VAWC Officer', 'VAWC Department', 'active'),
(6, 'Role', 'Role Dept', 'in-active'),
(7, 'Desk Officer', 'Desk Officer Department', 'active'),
(8, 'none', '', 'in-active'),
(9, '', '', 'in-active'),
(10, '', '', 'in-active');

-- Table `securityquestions` --
CREATE TABLE `securityquestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `securityquestions` (`id`, `name`) VALUES
(1, 'What was the name of your first pet?'),
(2, 'What was your childhood nickname?'),
(3, 'What is the model of your first car?');

-- Table `statuses` --
CREATE TABLE `statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `statuses` (`id`, `status`) VALUES
(1, 'Enabled'),
(2, 'Disabled');

-- Table `users` --
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT '1',
  `status_id` int(11) NOT NULL DEFAULT '1',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `login_check` timestamp NULL DEFAULT NULL,
  `logout_check` timestamp NULL DEFAULT NULL,
  `smsnotif` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `users_fk0` (`role_id`),
  KEY `users_fk1` (`status_id`),
  CONSTRAINT `users_fk0` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `users_fk1` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role_id`, `status_id`, `date_created`, `login_check`, `logout_check`, `smsnotif`) VALUES
(1, 'superadmin', '889a3a791b3875cfae413574b53da4bb8a90d53e', '', 2, 1, '2018-09-04 18:53:39', '2019-03-21 09:27:59', '2019-03-16 14:31:15', 1),
(2, 'deskofficer', 'dd785c67c6cedce1eeeb8333160095744aa10e7e', '', 7, 1, '2019-03-16 13:44:35', '2019-03-16 15:10:13', '2019-03-16 15:11:07', 1),
(3, 'lupontagapamayapa', '16faf9e4e3398247b5405e44d43b584931308b50', '', 3, 1, '2019-03-16 13:45:05', '', '', 1),
(4, 'bcpc', '6bb7f1a7fca86576c0b73a2cedc7d7d4f7b6c67d', '', 4, 1, '2019-03-16 13:45:49', '2019-03-16 15:11:12', '2019-03-16 15:14:43', 1),
(5, 'vawc', '9e76b202b4de042076f53e2c12f93f37fdfe5894', '', 5, 1, '2019-03-16 13:46:17', '2019-03-16 14:43:09', '2019-03-16 14:48:37', 1),
(6, 'deskofficer2', '784146472f8bcbfe05564acfc8e068ddd01ec31f', '', 7, 1, '2019-03-16 13:51:19', '', '', 1);

-- Table `users_info` --
CREATE TABLE `users_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `securityquestion` int(11) NOT NULL,
  `securityanswer` varchar(255) NOT NULL,
  `users_id` int(11) NOT NULL,
  `barangay_branch` enum('Santolan','Dela Paz','','') NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `users_info_fk0` (`securityquestion`),
  KEY `users_info_fk1` (`users_id`),
  CONSTRAINT `users_info_fk0` FOREIGN KEY (`securityquestion`) REFERENCES `securityquestions` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `users_info_fk1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `users_info` (`id`, `firstname`, `lastname`, `address`, `birthdate`, `contact_number`, `securityquestion`, `securityanswer`, `users_id`, `barangay_branch`) VALUES
(1, 'Kerwin', 'Francisco', 'Address', '05-05-1995', '123456789', 3, 'superadmin', 1, ''),
(2, 'deskofficer', 'deskofficer', 'deskofficer', '2000-01-01', '123456789', 1, 'deskofficer', 2, 'Dela Paz'),
(3, 'lupontagapamayapa', 'lupontagapamayapa', 'lupontagapamayapa', '2000-01-01', '123456789', 1, 'lupontagapamayapa', 3, 'Santolan'),
(4, 'bcpc', 'bcpc', 'bcpc', '2000-01-01', '123456789', 1, 'bcpc', 4, 'Santolan'),
(5, 'vawc', 'vawc', 'vawc', '2000-01-01', '123456789', 1, 'vawc', 5, 'Santolan'),
(6, 'deskofficer2', 'deskofficer2', 'deskofficer2', '2000-01-01', '123456789', 1, 'deskofficer2', 6, 'Santolan');

