<?php


require('template.php');
?>


<?php function gettitle(){
	echo 'Register';
} ?>



<?php function getcontent(){ 
	require('../connection.php');
	?>

<div class="container" style="margin-top: 50px;">
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Create New User Account</h5>
    <hr>
  <div class="row">
    <div class="col-md-12">
    	<!-- controllers/adduser_endpoint.php -->
        	<form id="register_form" action="controllers/adduser_endpoint.php" method="POST">
        	<div class="col-md-5 offset-md-3">
			<h5>Login Account Information</h5>
			</div>

        <div class="col-md-5 offset-md-3">	
			<label id="usernamelabel">Username: </label>
			<input type="text" class="form-control" id="username" name="username">
			
        </div>

        	<div class="col-md-5 offset-md-3">
				<label id="passwordlabel" for="password">Password: </label>
				<input type="password" class="form-control" id="password" name="password">
				
			</div>

			<div class="col-md-5 offset-md-3">
			<label id="confirmpasslabel" for="confirm_password">Confirm Password: </label>
			<input type="password" class="form-control" id="confirm_password" name="confirm_password">
			
			</div>
			
 			<div class="col-md-5 offset-md-3">
			<h5>User Account Information</h5>
			</div>

			

			<div class="col-md-5 offset-md-3">	
				<label id="firstnamelabel" for="firstname"> First name </label>
				<input type="text" class="form-control" id="firstname" name="firstname">
        	</div>

        	 <div class="col-md-5 offset-md-3">	
				<label id="lastnamelabel" for="lastname"> Last name </label>
				<input type="text" class="form-control" id="lastname" name="lastname">
        	</div>


        	 <div class="col-md-5 offset-md-3">	
				<label id="addresslabel" for="address"> Address </label>
				<input type="text" class="form-control" id="address" name="address">
        	</div>

        	 <div class="col-md-5 offset-md-3">	
				<label id="birthdatelabel" for="birthdate"> birthdate</label>
				<input type="date" class="form-control" id="birthdate" name="birthdate" value="2000-01-01">
        	</div>

        	 <div class="col-md-5 offset-md-3">	
				<label id="contactnumlabel" for="contactnumber"> Contact number </label>

				<input class="form-control" id="contactnumber" placeholder="0920#######" name="contactnumber" min="0" maxlength="11" type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />

        	</div>

        	<div class="col-md-5 offset-md-3">	
				<label id="barangay_branch_label" for="barangay_branch"> Barangay Branch:  </label>
				<select class="form-control" id="barangay_branch" name="barangay_branch">
					<option value="Santolan">Santolan</option>
					<option value="Dela Paz">Dela Paz</option>
				</select>
        	</div>



        	<div class="col-md-5 offset-md-3">	
				<label id="rolelabel" for="role"> Role </label>
				<select id="role" class="form-control" name="role" required>
				<option disabled selected>Select Role</option> 
           <?php 
                $sql = "SELECT * FROM roles WHERE status = 'active'";
                $results = mysqli_query($conn, $sql);
                foreach ($results as $result ){ 
                  extract($result); ?>
                    <option value="<?php echo $id; ?>"><?php echo $role; ?></option> 
                      <?php }?> 
		            </select>
					
        	</div>


        	 <div class="col-md-5 offset-md-3">	
				<label id="secquelabel" for="securityquestion"> Security Question </label>
				<select class="form-control" id="securityquestion" name="securityquestion" required>
				<option disabled selected>Select Security question</option> 
           <?php 
                $sql = "SELECT * FROM securityquestions";
                $results = mysqli_query($conn, $sql);
                foreach ($results as $result ){ 
                  extract($result); ?>
                    <option value="<?php echo $id; ?>"><?php echo $name; ?></option> 
                      <?php }?> 
		            </select>
        	</div>

        	 <div class="col-md-5 offset-md-3">	
				<label id="secuanswerlabel" for="securityanswer"> Security Answer </label>
				<input type="text" class="form-control" id="securityanswer" name="securityanswer">
        	</div>
    </div>
        <div class="col-md-5 offset-md-4">
        	<br>
			<button type="button" id="registerbtn" class="btn btn-primary" >Create Account</button>
			</form>
        </div>
  </div>
  </div>
</div>
</div>


























<script>
	// AJAX USERNAME 



// jsprint(validate, "4/10/1995");

// alert($('#birthdate').val());

$('#registerbtn').click( () => {
	const username = $('#username').val();
	// const email = $('#email').val();
	const firstname = $('#firstname').val();
	const password = $('#password').val();
	const confirm_password = $('#confirm_password').val();
	const lastname = $('#lastname').val();
	const address = $('#address').val();
	const birthdate = $('#birthdate').val();
	const contactnumber = $('#contactnumber').val();
	const securityanswer = $('#securityanswer').val();
	let errorFlag = false;

	$.ajax({
		url : 'controllers/check_username.php',
		method : 'post',
		data : {username : username},
		async : false
	}).done ( data => {
		if(data == 'invalid'){
		errorFlag = true; // set to true 
		$('#usernamelabel').css('color' , 'red');
		$('#username').next().html('username already exist');
		swal({
				title: "Error",
				text: "Username Already Exist",
				icon: "error",
				button: "OK",
			});
		} else {
			$('#username').next().css('color' , 'green');
		$('#username').next().html('username still available');
		}
	});

	

	if(username.length == 0 ) {
		errorFlag = true;
		$('#usernamelabel').css('color' , 'red');
		$('#username').next().html('Please Check all the required fields');
		swal({
				title: "Error",
				text: "Please Check all the required fields",
				icon: "error",
				button: "OK",
			});
	} 

	if(password.length == 0 ) {
		errorFlag = true;
		$('#passwordlabel').css('color' , 'red');
		$('#password').next().html('Please Check all the required fields');
		swal({
				title: "Error",
				text: "Please Check all the required fields",
				icon: "error",
				button: "OK",
			});
	} 


	if(password.length == 0 ) {
		errorFlag = true;
		$('#confirmpasslabel').css('color' , 'red');
		$('#password').next().html('Please Check all the required fields');
		swal({
				title: "Error",
				text: "Please Check all the required fields",
				icon: "error",
				button: "OK",
			});
	} 


	// alert(birthdate);

	validate(birthdate);
function validate(date){


    var eighteenYearsAgo = moment().subtract(18, "years");
    var birthday = moment(date);
    
    if (!birthday.isValid()) {
        // alert("invalid date");    
        errorFlag = true;
        swal({
				title: "Error",
				text: "Invalid Date",
				icon: "error",
				button: "OK",
			});
    }
    else if (eighteenYearsAgo.isAfter(birthday)) {
         // alert("okay, you're good");
         errorFlag = false;
        
    }
    else {
        // alert("sorry, no"); 
        errorFlag = true;
        // $('#birthdate').next().css('color' , 'red');
		// $('#birthdate').next().html('You have to be 18 and above');   
		swal({
				title: "Error",
				text: "Employee has to be 18 and above",
				icon: "error",
				button: "OK",
			});
    }
    }



// 	validate(birthdate);
// function validate(date){
//     var eighteenYearsAgo = moment().subtract(18, "years");
//     var birthday = moment(date);
    
//     if (!birthday.isValid()) {
//         alert("invalid date");    
//     }
//     else if (eighteenYearsAgo.isAfter(birthday)) {
//          alert("okay, you're good");    
//     }
//     else {
//         alert("sorry, no");    
//     }
// }











	if(firstname.length == 0 ) {
		errorFlag = true;
		$('#firstnamelabel').css('color' , 'red');
		$('#firstname').next().html('Please Check all the required fields');
		swal({
				title: "Error",
				text: "First Name field is required",
				icon: "error",
				button: "OK",
			});
	} 


	if(lastname.length == 0 ) {
		errorFlag = true;
		$('#lastnamelabel').css('color' , 'red');
		$('#lastname').next().html('Please Check all the required fields');
		swal({
				title: "Error",
				text: "Last Name field is required",
				icon: "error",
				button: "OK",
			});
	} 


	if(address.length == 0 ) {
		errorFlag = true;
		$('#addresslabel').css('color' , 'red');
		$('#address').next().html('Please Check all the required fields');
		swal({
				title: "Error",
				text: "Please Check all the required fields",
				icon: "error",
				button: "OK",
			});
	} 


	if(birthdate.length == 0 ) {
		errorFlag = true;
		$('#addresslabel').css('color' , 'red');
		$('#birthdate').next().html('this field is required');
		swal({
				title: "Error",
				text: "Please Check all the required fields",
				icon: "error",
				button: "OK",
			});
	} 







	if(contactnumber.length == 0 ) {
		errorFlag = true;
		$('#contactnumlabel').css('color' , 'red');
		$('#contactnumber').next().html('this field is required');
		swal({
				title: "Error",
				text: "Please Check all the required fields",
				icon: "error",
				button: "OK",
			});
	} 


	if(securityanswer.length == 0 ) {
		errorFlag = true;
		$('#secuanswerlabel').css('color' , 'red');
		$('#securityanswer').next().html('this field is required');
		swal({
				title: "Error",
				text: "Please Check all the required fields",
				icon: "error",
				button: "OK",
			});
	} 



	else {
	
	 const password = $('#password').val();
	 const confirmPassword = $('#confirm_password').val();

	 if(password.length == 0) {
	 	errorFlag = true;
	 	$('#passwordlabel').css('color' , 'red');
	 	$('#password').next().html('this field is required');
	 	swal({
				title: "Error",
				text: "Please Check all the required fields",
				icon: "error",
				button: "OK",
			});
	 }
	 else{

	 if(password !== confirmPassword ){
	 	errorFlag = true;
	 	$('#confirmpasslabel').css('color' , 'red');
	 	$('#confirm_password').next().html('password did not match');

	 	swal({
				title: "Error",
				text: "Password did not match",
				icon: "error",
				button: "OK",
			});

		 }
	 else
	 {
	 	$('#confirm_password').next().html('');
	 }
	}
 }

if(errorFlag == false){
	$('#register_form').submit();
}

});


</script>

<?php } ?>