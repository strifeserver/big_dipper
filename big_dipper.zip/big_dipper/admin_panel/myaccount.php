<?php 


require_once('template.php');

function gettitle(){
	echo 'My profile';
}


function getcontent(){ ?>

        <?php 
        if(isset($_SESSION['logged_in_user'])){
        $loggedindata = $_SESSION['logged_in_user'];
        require('../connection.php');
        $sql = "SELECT * FROM users as u JOIN users_info as ui ON (u.id = ui.users_id) JOIN roles as r ON (u.role_id = r.id) WHERE u.username = '$loggedindata'";
        $result = mysqli_query($conn, $sql);
        $result = mysqli_fetch_array($result);
        extract($result);
         ?>

<div class="container">
  <div class="row">
  	<div class="card col-md-12">
  		  <div class="card-body">
  		    <h5 class="card-title">My Profile</h5>
  		    <p class="card-text">Account Information</p>
  		    <hr>
  		    <p class="card-text"><strong>Username</strong></p>

  		    <div class="col-md-3">
  			    <div class="input-group mb-1">
  				  <div class="input-group-prepend">
  				    <span class="input-group-text" id="basic-addon1">@</span>
  				  </div>
  				  <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $username ?>" disabled>
  				</div>
  			</div>

  			<p class="card-text"><strong>Full Name</strong></p>
  			<div class="col-md-3">
  			    <div class="input-group mb-1">
  				  <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $firstname . ' ' . $lastname; ?>" disabled>
  				</div>
  			</div>

  			<p class="card-text"><strong>Contact Number</strong></p>
  			<div class="col-md-3">
  			    <div class="input-group mb-1">
  				  <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $contact_number; ?>" disabled>
  				</div>
  			</div>

        <br>
        <hr>

        <div class="col-md-4">
          <?php 

            require('../connection.php');
            $username =  $_SESSION['logged_in_user'];
            $sql = "SELECT * FROM users WHERE username = '$username'";
            $result = mysqli_query($conn, $sql);
            $getprofile = mysqli_fetch_assoc($result);
            $id = $getprofile['id'];
            $email_address = $getprofile['email'];
            $role = $getprofile['role_id'];
            // echo $id;


            $sql = "SELECT * FROM users_info WHERE users_id = '$id'";
            $result = mysqli_query($conn, $sql);
            $profileinfo = mysqli_fetch_assoc($result);


            $getsq = "SELECT ui.id, securityquestion,name FROM users_info as ui JOIN securityquestions as sq ON (ui.securityquestion = sq.id) WHERE ui.id = '$id'";
            $resultsq = mysqli_query($conn, $getsq);
            $sq = mysqli_fetch_assoc($resultsq);





           ?>
        <form id="register_form" action="../controllers/changepassword_endpoint.php?id=<?php echo $id;?>"" method="POST">
          <label for="securityquestion_id"><strong>Security Question:</strong></label>
          <input type="text" id="securityquestion_id" name="securityquestion_id" class="form-control" aria-label="securityanswer" aria-describedby="basic-addon1" value="<?php echo $sq['name']; ?>" disabled>
          <label for="securityanswer"><strong>Security Answer:</strong> </label>
          <input type="text" class="form-control" id="securityanswer" name="securityanswer">
          <p></p>
          <?php 
              if(isset($_SESSION['error_message']))
              {
                echo "<span class='error_message'>" . $_SESSION['error_message'] . " </span>";
                unset($_SESSION['error_message']);
              }
          ?>


          <?php 
              if(isset($_SESSION['passchanged']))
              {
                echo "<span class='error_message'>" . $_SESSION['passchanged'] . " </span>";
                unset($_SESSION['passchanged']);
              }
          ?>

          <label for="password"><strong>New Password:</strong></label>
          <input type="password" class="form-control" id="password" name="password">
          <p></p>

          <label for="confirm_password"><strong>Confirm Password:</strong></label>
          <input type="password" class="form-control" id="confirm_password" name="confirm_password">
          <p></p>
          <br>
          <button type="button" id="registerBtn" class="btn btn-primary">Change Password</button>
        </form>
        </div>
  			<hr>
  			   <p class="card-text"><strong>Login Audits</strong></p>
    			<div class="col-md-4">
    			    <div class="input-group mb-2">
    				 <span style="text-align: right; margin-right: 10px;">Last login:</span> <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $login_check; ?>" disabled>
    				</div>

    				 <div class="input-group mb-2">
    				  <span style="text-align: right;">Last logout:</span><input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $logout_check; ?>" disabled>
    				</div>
    			</div>
  		  </div>
  	</div>
  </div>
</div>
            
 


<link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
          <h2>Activities</h2>
              <?php 
                $sql = "SELECT * FROM audits as s JOIN users as u ON (s.account_id = u.id) WHERE username = '$loggedindata' ";
                $results = mysqli_query($conn, $sql);
               ?>
              <table id="table_id" class="display">
                <thead>
                    <tr>
                      <th>Activity</th>
                      <th>Date/Time</th>
                    </tr>
                </thead>
                <tbody>
                  <?php foreach ($results as $result ){ 
                              extract($result);
                  ?>
                  <tr>
                    <td><?php echo $activity; ?> </td>
                    <td><?php echo $datetime; ?> </td>
                  </tr>
                   <?php } ?> 
                </tbody>
              </table>
      </div>
    </div>
  </div>


<script type="text/javascript" src="assets/js/datatables.min.js"></script>

<script>
    // AJAX USERNAME 
$('#registerBtn').click( () => {

  let errorFlag = false;
   const password = $('#password').val();
   const confirmPassword = $('#confirm_password').val();

   if(password.length == 0) {
    errorFlag = true;
    $('#password').next().css('color' , 'red');
    $('#password').next().html('this field is required');
   }




   else{

   if(password !== confirmPassword ){
    errorFlag = true;
    $('#confirm_password').next().css('color' , 'red');
    $('#confirm_password').next().html('password did not match');
     }
   else
   {
    $('#confirm_password').next().html('');
   }
  }
 

if(errorFlag == false){
  $('#register_form').submit();
}

});


  

$(document).ready( function () {
    $('#table_id').DataTable();
} );

</script>




<?php }}  ?>
