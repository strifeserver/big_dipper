<?php


require('template.php');
?>


<?php function gettitle(){
	echo 'Add Role';
} ?>



<?php function getcontent(){ 
	require('../connection.php');
	?>

<div class="container" style="margin-top: 50px;">
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Create New User Role</h5>
    <hr>
  <div class="row">
    <div class="col-md-12">
        	<form id="register_form" action="controllers/addrole_endpoint.php" method="POST">
        	<div class="col-md-5 offset-md-3">
			<h5>New Role</h5>
			</div>

        <div class="col-md-5 offset-md-3">	
			<label for="role">role: </label>
			<input type="text" class="form-control" id="role" name="role">
			
        </div>

    </div>
        <div class="col-md-5 offset-md-4">
        	<br>
			<button type="button" id="registerbtn" class="btn btn-primary" >Create Role</button>
			</form>
        </div>
  </div>
  </div>
</div>
</div>





<script>
	// AJAX role 
$('#registerbtn').click( () => {
	const role = $('#role').val();
	let errorFlag = false;

	$.ajax({
		url : 'controllers/check_role.php',
		method : 'post',
		data : {role : role},
		async : false
	}).done ( data => {
		if(data == 'invalid'){
		errorFlag = true; // set to true 
		$('#role').next().css('color' , 'red');
		$('#role').next().html('role already exist');
		} else {
			$('#role').next().css('color' , 'green');
		$('#role').next().html('role still available');
		}
	});

	

	if(role.length == 0 ) {
		errorFlag = true;
		$('#role').next().css('color' , 'red');
		$('#role').next().html('this field is required');
	} 



if(errorFlag == false){
	$('#register_form').submit();
}

});


</script>

<?php } ?>