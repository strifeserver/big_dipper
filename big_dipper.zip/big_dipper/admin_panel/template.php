<?php 
session_start();
		


		require('../connection.php');
		$loggedindata = $_SESSION['logged_in_user'];
        $sql = "SELECT * FROM users as u JOIN users_info as ui ON (u.id = ui.users_id) JOIN roles as r ON (u.role_id = r.id)
        WHERE u.username = '$loggedindata'";
        $result = mysqli_query($conn, $sql);
        $result = mysqli_fetch_array($result);
        extract($result);

// unset($_SESSION['logged_in_user']);
if($loggedindata){




 ?>


<!DOCTYPE html>
<html>
<head>
	<title><?php gettitle(); ?></title>
	<?php require_once('partials/headers.php');?>
</head>

<body>



		<?php require_once('partials/nav.php');?>










<div class="row">
	<div class="offset-s2 col s9">
		<?php 
getcontent(); 
?>
	</div>
</div>


<span class="notification" style="display: none;"><?php if(isset($_SESSION['notification']) == true){echo '1';}else {echo '0';}; ?></span>
</body>
<script>
	M.AutoInit();
	var notifier = $('.notification').html()
	if(notifier == '1'){
		swal(<?php if(isset($_SESSION['notification']) == true){echo json_encode($_SESSION['notification']);}else {echo '0';}; ?>);
	}
</script>
</html>


<?php } else {
	header('location: ../login.php');
} 
?>

<?php

unset($_SESSION['notification']);
  ?>