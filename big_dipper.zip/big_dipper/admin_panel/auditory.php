<?php 


require_once('template.php');

function gettitle(){
    echo 'Auditory View';
}


function getcontent(){



?>
<link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>

<div class="container">





 <div class="row">

    <div class="col s12 m7 l12 offset-l1">
      <h3 class="offset-md-4" style="margin-top: 40px;">Audit Management</h3>


      <div class="card">

        <div class="card-content">

          <?php 

            require('../connection.php');
            $sql = "SELECT * FROM audits as s JOIN users as u ON (s.account_id = u.id) ";
            $results = mysqli_query($conn, $sql);
           ?>
          <table id="table_id" class="display" >
    <thead>
        <tr>
            <!-- <th>ID</th> -->
            <th>Activity</th>
            <th>Date/Time</th>

        </tr>
    </thead>
    <tbody>

  <?php foreach ($results as $result ){ 
                  extract($result);
                    ?>
        <tr>
            <td><?php echo $activity; ?> </td>
            <td><?php echo $datetime; ?> </td>

        </tr>
          <?php } ?> 

    </tbody>
</table>
      </div>
    </div>
  </div>
</div>

<div class="row" style="margin-top: 50px;">
  <div class="col-md-3 offset-md-5">
    <a class="btn btn-dark" href="maintenance.php">Back</a>
  </div>
</div>

<script type="text/javascript" src="assets/js/datatables.min.js"></script>

<script>
  

$(document).ready( function () {
    $('#table_id').DataTable();
} );

</script>
<?php } ?>

