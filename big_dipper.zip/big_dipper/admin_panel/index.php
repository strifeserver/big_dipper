<?php 


require_once('template.php');

function gettitle(){
	echo 'Home';
}
function getcontent(){ ?>
<?php 
require('../connection.php');
	$loggedindata = $_SESSION['logged_in_user'];
       $sql = "SELECT * FROM users as u JOIN users_info as ui ON (u.id = ui.users_id) JOIN roles as r ON (u.role_id = r.id)
        WHERE u.username = '$loggedindata'";
        $result = mysqli_query($conn, $sql);
        $result = mysqli_fetch_array($result);
        extract($result);
 ?>
<?php } ?>
