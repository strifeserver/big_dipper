

<?php 
session_start();
$loggedindata = $_SESSION['logged_in_user'];
	require('../connection.php');



$sql = "SELECT barangay_branch FROM users
JOIN users_info on users.id = users_info.users_id WHERE users.username = '$loggedindata'";

$result = mysqli_query($conn, $sql);
$result = mysqli_fetch_assoc($result);
extract($result);

	?>

<div class="container" style="margin-top: 50px;">
  <!-- <div style="position: fixed; bottom: 1px;"><?php echo  $loggedindata; ?></div> -->
<div class="card">
 
<?php 
if($barangay_branch == 'Santolan'){
?>
<center><img src="assets/images/brgy_santolan_gray.png" style="height: 120px; width: 120px;" >
<p>Barangay Santolan Evangelista Ave., Santolan, Pasig City
</p>
<p>Contact us at 6811614</p>
</center>
<?php
} 
?>

<?php 
if($barangay_branch == 'Dela Paz'){
?>
<center><img src="assets/images/brgy_delapaz_gray.png" style="height: 120px; width: 120px;">



<p>Barangay Dela Paz 
      F. Mariano Ave., Pasig City
      </p>
      <p>Contact us at 6452331</p>
</center>
<?php
} 
?>

<table style="width:100%">
  <tr  style="font-weight: bold;"><td>Date Printed: <?php echo date("Y/m/d"); ?></td></tr>
  <tr  style="font-weight: bold;"><td>Printed by: <?php echo $loggedindata; ?></td></tr>
</table>

</div>
</div>


<?php 

$filter = '';
$status = "all";
$filter_date = '';



if(isset($_GET['status'])){
	$status = $_GET['status'];
	if($status != 'all'){
    
		$filter = "WHERE cs.complaint_status = '$status'";

	}
}


if($_GET['datea'] && $_GET['dateb']){

$datea = $_GET['datea'];
$dateb = $_GET['dateb'];

$filter_date = "AND bc.date_created BETWEEN '$datea' AND '$dateb'";

}



$sql = "SELECT bc.complaint_reference, bc.date_updated, bc.date_created, bc.id, bc.title, cc.complaint_category, cs.complaint_status, u.username
            FROM `barangay_complaints` bc
            JOIN complaint_categories cc ON (cc.id = bc.complaint_category)
            JOIN complaint_status cs ON (cs.id = bc.complaint_status)
            JOIN users u ON (u.id = bc.submitted_by) $filter $filter_date";
$results = mysqli_query($conn, $sql);
// $results = mysqli_fetch_assoc($result);

// echo $sql;



$pending_sql = "SELECT count(id) as pendings FROM barangay_complaints WHERE complaint_status = '1'";
$count_pending = mysqli_query($conn, $pending_sql);
$pending_res = mysqli_fetch_assoc($count_pending);
extract($pending_res);
$closed_sql = "SELECT count(id) as closeds FROM barangay_complaints WHERE complaint_status = '2'";
$count_closed = mysqli_query($conn, $closed_sql);
$closed_res = mysqli_fetch_assoc($count_closed);
extract($closed_res);
 ?>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  /*background-color: #4CAF50;*/
  color: black;
}
</style>




<div>
	
</div>
<!-- pendings -->
<!-- closeds -->
<?php if($status == 'all'){ ?>
<p><?php echo 'There are <b>'.$pendings.' pending cases</b>'; ?></p>
<p><?php echo 'There are <b>'.$closeds.' closed cases</b>'; ?></p>
          <?php } ?>
          <table id="customers" class="display">
    <thead>
        <tr>
            <!-- <th>ID</th> -->
            <th>Reference #</th>
            <th>title</th>
            <th>complaint category</th>
            <th>complaint status</th>
            <th>submitted by</th>
            <th style="width: 100px;">Date Updated</th>
            <th>Date Recorded</th>

        </tr>
    </thead>
    <tbody>

  <?php foreach ($results as $result ){ 
                  extract($result);
                    ?>
        <tr>
            <td><?php echo $complaint_reference; ?> </td>
            <td><?php echo $title; ?> </td>
            <td><?php echo $complaint_category; ?> </td>
            <td <?php if($complaint_status == 'Pending'){ echo 'class="btn btn-danger" style="margin-top: 20px;"';} ?>  ><?php echo $complaint_status; ?> </td>
            <td><?php echo $username; ?> </td>
            <td style="font-size: 12px;"><?php echo $date_updated; ?> </td>
            <td style="font-size: 12px;"><?php echo $date_created; ?> </td>

         

        </tr>
          <?php } ?> 

    </tbody>
</table>



<script>
	<!--
window.print();
//-->
</script>