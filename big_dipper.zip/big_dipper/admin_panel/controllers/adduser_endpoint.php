<?php 
session_start();
require('../../connection.php');
$username = $_POST['username'];
$password = sha1($_POST['password']);
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$address = $_POST['address'];
$birthdate = $_POST['birthdate'];
$contactnumber = $_POST['contactnumber'];
$securityquestion = $_POST['securityquestion'];
$securityanswer = $_POST['securityanswer'];

$sql = "INSERT INTO users(
username, 
password
)
VALUES (
'$username', 
'$password'
)";
$result = mysqli_query($conn, $sql);
if($result)
{
	// get the username to get the id
	$sql = "SELECT * FROM users WHERE username = '$username' ";
	$result = mysqli_query($conn, $sql);
	$getid = mysqli_fetch_array($result);
}
if($result){
$users_id = $getid['id'];
$sql = "INSERT INTO users_info(firstname, 
lastname, 
address, 
birthdate, 
contact_number, 
securityquestion, 
securityanswer,
users_id
)
VALUES (
'$firstname', 
'$lastname', 
'$address', 
'$birthdate', 
'$contactnumber', 
'$securityquestion', 
'$securityanswer',
'$users_id'
)";
mysqli_query($conn, $sql) or die(mysqli_error($conn));

	$_SESSION['notification'] = array("title"=>"Success", "text"=>"Create user success", "icon"=>"success", "button"=>"ok");
// auditory tracker






$loggedindata = $_SESSION['logged_in_user'];
$sql = "SELECT * FROM users WHERE username = '$loggedindata'";
$result = mysqli_query($conn, $sql);
$result = mysqli_fetch_array($result);
$account_id = $result['id'];
$sql = "INSERT INTO audits(
activity, 
account_id
)
VALUES (
'$loggedindata Created a User Account under username of: $username', 
'$account_id'
)";
mysqli_query($conn, $sql) or die(mysqli_error($conn));
// auditory end
$_SESSION['success'] = "User successfully added!";
header('location: ../displayusers.php');
}?>