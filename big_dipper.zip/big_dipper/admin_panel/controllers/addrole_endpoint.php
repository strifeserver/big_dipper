<?php 
session_start();
require('../../connection.php');

$role = $_POST['role'];

$sql = "INSERT INTO roles(
role
)
VALUES (
'$role')";

$result = mysqli_query($conn, $sql);

if($result){
	$_SESSION['notification'] = array("title"=>"Success", "text"=>"Add role success", "icon"=>"success", "button"=>"ok");
} else {
	$_SESSION['notification'] = array("title"=>"Error", "text"=>"Add role Failed", "icon"=>"error", "button"=>"ok");
}





// auditory tracker
$loggedindata = $_SESSION['logged_in_user'];
$sql = "SELECT * FROM users WHERE username = '$loggedindata'";
$result = mysqli_query($conn, $sql);
$result = mysqli_fetch_array($result);



$account_id = $result['id'];

$sql = "INSERT INTO audits(
activity, 
account_id
)
VALUES (
'MODULE | Role Control | USER: $loggedindata | ACTION: INSERT | INSERT: $role  ', 
'$account_id'
)";
mysqli_query($conn, $sql) or die(mysqli_error($conn));


// auditory end




$_SESSION['success'] = "User successfully added!";
header('location: ../displayusers.php');

















 ?>