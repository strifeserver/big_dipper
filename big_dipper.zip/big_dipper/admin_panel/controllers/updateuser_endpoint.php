<?php 
session_start();
require('../../connection.php');

$id = $_GET['id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$address = $_POST['address'];
$birthdate = $_POST['birthdate'];
$contactnumber = $_POST['contactnumber'];
$role = $_POST['role'];
$status = $_POST['status'];
$barangay_branch = $_POST['barangay_branch'];


$sql = "UPDATE users_info SET 
firstname = '$firstname', 
lastname = '$lastname', 
address = '$address', 
birthdate = '$birthdate', 
contact_number = '$contactnumber', 
barangay_branch = '$barangay_branch' 
WHERE id =$id";
$result = mysqli_query($conn, $sql);

if($result){

$sql = "UPDATE users SET 
role_id = '$role', 
status_id = '$status'
 
WHERE id = '$id' ";
$result = mysqli_query($conn, $sql);

// $result = mysqli_query($conn, $sql);



}

//notification
if($result){
	$_SESSION['notification'] = array("title"=>"Success", "text"=>"Update user success", "icon"=>"success", "button"=>"ok");
} else {
	$_SESSION['notification'] = array("title"=>"Error", "text"=>"Update user failed", "icon"=>"error", "button"=>"ok");
}


$sql = "SELECT u.username, r.role FROM users as u JOIN roles as r ON (u.role_id = r.id) WHERE u.id = '$id'";
$results = mysqli_query($conn, $sql);
$results = mysqli_fetch_array($results);

$getuser = $results['username'];
$getrole = $results['role'];




// auditory checker
$loggedindata = $_SESSION['logged_in_user'];
$sql = "SELECT * FROM users WHERE username = '$loggedindata'";
$result = mysqli_query($conn, $sql);
$result = mysqli_fetch_array($result);



$account_id = $result['id'];

$sql = "INSERT INTO audits(
activity, 
account_id
)
VALUES (
'MODULE | Accounts Management | USER: $loggedindata | ACTION: UPDATE |  TARGET: $getuser, ($getrole) ', 
'$account_id'
)";
mysqli_query($conn, $sql) or die(mysqli_error($conn));


// auditory end









$_SESSION['success'] = "User Account Successfully Updated!";
header('location: ../displayusers.php');



 ?>