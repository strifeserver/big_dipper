<?php
require('../connection.php');

$username = $_POST['username'];

$sql = "SELECT * FROM users WHERE username = '$username'";


$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	echo 'invalid';
} else {
	echo 'valid';
}




 ?>