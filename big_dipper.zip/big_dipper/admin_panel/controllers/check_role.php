<?php
require('../connection.php');

$role = $_POST['role'];

$sql = "SELECT * FROM roles WHERE role = '$role'";


$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	echo 'invalid';
} else {
	echo 'valid';
}




 ?>