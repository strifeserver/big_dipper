<?php 


require_once('template.php');

function gettitle(){
    echo 'Maintenance';
}


function getcontent(){
?>

<div class="col-md-12">
	<div style="margin-top: 50px;"class="col-md-5 ">
	<!-- <h2>Maintenance</h2> -->
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<a class="nav-link itemmaintenance" href="displayusers.php"><i class="fa fa-users fa-2x"></i> <br>Account Management</a>
			</div>
			<div class="col-md-3">
				<a class="nav-link itemmaintenance" href="auditory.php"><i class="fas fa-book-open fa-2x"></i> <br>Auditory Management</a>
			</div>

			<div class="col-md-3">
				<a class="nav-link itemmaintenance" href="database_management.php"><i class="fas fa-database fa-2x"></i></i><br>Database Management</a>
			</div>
	
		</div>
		<div class="row" style="margin-top: 50px;">
			
	
		</div>
	</div>
</div>





<?php } ?>

