<?php 
session_start();
 ?>

<!DOCTYPE html>
<html>
<head>
	<title><?php gettitle(); ?></title>
	
	<?php require_once('partials/header.php');?>
</head>

<body style="background-color: #449DD1;">
<?php require_once('partials/nav.php');?>



<?php 
getcontent(); 



?>






</body>
</html>