<?php $loggedindata = $_SESSION['logged_in_user']; ?>
  <div class="col s12" style="">
      <div class="row" style="background-color: black; color: white; margin: 0px; padding: 0px;">
        <div class="col s12" style="margin-top: 5px;">
          <!-- <img src="assets/images/big_dipper.jpg" style="height: 100px; width: 100px;"> -->
        </div>
        <div class="col-md-6" style="text-align: right;">   
        <?php 
        echo 'Hi '.$loggedindata.' | ';
          date_default_timezone_set("Asia/Taipei");
          $timestamp = time(); 
          echo(date("F d, Y h:i A", $timestamp)); 
        ?>
        </div>
      </div>
  </div>
  



 <ul id="slide-out" class="sidenav sidenav-fixed" style="">
  <li><div class="user-view" style="height: 270px;">
      <div class="background" >
        <img src="assets/images/big_dipper.jpg" >
      </div>
      <!-- <a href="#user"><img class="circle" src="images/yuna.jpg"></a>
      <a href="#name"><span class=" name">John Doe</span></a>
      <a href="#email"><span class=" email">jdandturk@gmail.com</span></a> -->
    </div></li>
    <li><div class="divider"></div></li>
      <li><a href="index.php">Home</a></li>
      <?php if($role =="Administrator"){ ?>
      <li><a href="maintenance.php">Maintenance</a></li>
      <?php } ?>
      <li><a href="myaccount.php">My Account</a></li>
      <li><a href="help.php">Help</a></li>
      <li><a href="../logout.php">Logout</a></li>
    </ul>
    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>





