
      <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
      <link rel="stylesheet" type="text/css" href="../assets/css/all.css">

      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>


       <link rel="stylesheet" href="../assets/css/materialize.min.css">
       <script type="text/javascript" src="../assets/js/all.js"></script>
       <script type="text/javascript" src="../assets/js/jquery-3.3.1.min.js"></script>
       <script type="text/javascript" src="assets/js/jsprint.min.js"></script>
       <script type="text/javascript" src="assets/js/moment.min.js"></script>
       <script type="text/javascript" src="assets/js/sweetalert.min.js"></script>

     <script type="text/javascript" src="assets/timepicker/jquery.timepicker.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/timepicker/jquery.timepicker.css" />
	<script type="text/javascript" src="assets/timepicker/bootstrap-datepicker.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/timepicker/bootstrap-datepicker.css" />


<script src="../assets/js/materialize.js"></script> 
<link href="../assets/css/summernote.css" rel="stylesheet">
<script src="../assets/js/summernote.js"></script>