<?php 


require_once('template.php');

function gettitle(){
    echo 'Auditory View';
}


function getcontent(){



?>
<link rel="stylesheet" type="text/css" href="assets/css/datatables.min.css"/>

<div class="container">





 <div class="">

    <div class="col s12 m7 l12 offset-l1">
      <h3 class="offset-md-4" style="margin-top: 40px;">Account Management</h3>
      <a class="btn btn-dark" href="adduser.php">Create Account</a>

      <div class="card">

        <div class="card-content">

          <?php 
            require('../connection.php');
            $sql = "SELECT * FROM users as u 
            JOIN roles as r ON (u.role_id = r.id) 
            JOIN statuses as s ON (u.status_id = s.id)
            JOIN users_info as ui ON (u.id = ui.users_id) ";
            $results = mysqli_query($conn, $sql);
           ?>
          <table id="table_id" class="display">
    <thead>
        <tr>
            <!-- <th>ID</th> -->
            <th>Username</th>
            <th>Full Name</th>
            <th>Role</th>
            <th>Status</th>
            <th>Date created</th>
            <th>Action</th>

        </tr>
    </thead>
    <tbody>
  <?php foreach ($results as $result ){ 
                  extract($result);
                    ?>
        <tr>
            <td><?php echo $username; ?> </td>
            <td><?php echo $firstname . ' ' . $lastname; ?> </td> 
            <td><?php echo $role; ?> </td>
            <td><?php echo $status; ?> </td>
            <td><?php echo $date_created; ?> </td>
            <td><a class="btn btn-dark" href="updateuser.php?id=<?php echo $id; ?>">Edit</a> 
            <a class="btn btn-dark" disabled href="updateuser.php?id=<?php echo $id; ?>">Lock</a></td>  
        </tr>
          <?php } ?> 

    </tbody>
</table>
      </div>
    </div>
  </div>
</div>

<div class="row" style="margin-top: 50px;">
  <div class="col-md-3 offset-md-5">
    <a class="btn btn-dark" href="maintenance.php">Back</a>
  </div>
</div>


<script type="text/javascript" src="assets/js/datatables.min.js"></script>

<script>
  

$(document).ready( function () {
    $('#table_id').DataTable();
} );

</script>
<?php } ?>

